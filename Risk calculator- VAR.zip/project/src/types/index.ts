export interface VaRHistoricalInputs {
  historicalPrices: number[];
  confidenceLevel: number;
  portfolioValue: number;
}

export interface VaRVarianceCovarianceInputs {
  averageReturn: number;
  standardDeviation: number;
  confidenceLevel: number;
  portfolioValue: number;
  timeHorizon: number;
}

export interface VaRMonteCarloInputs {
  averageReturn: number;
  volatility: number;
  confidenceLevel: number;
  portfolioValue: number;
  timeHorizon: number;
  numSimulations: number;
}

export interface CRMInputs {
  totalExposure: number;
  riskFactors: number[];
  timeHorizon: number;
  correlationCoefficients: number[];
}

export interface IRCInputs {
  portfolioCashFlows: number[];
  defaultProbabilities: number[];
  recoveryRates: number[];
  timeFrame: number;
}

export interface IDRInputs {
  defaultProbability: number;
  historicalDefaultRates: number[];
  lossGivenDefault: number;
  exposure: number;
}

export type RiskCalculationType = 'var' | 'crm' | 'irc' | 'idr';
export type VaRMethodType = 'historical' | 'variance-covariance' | 'monte-carlo';