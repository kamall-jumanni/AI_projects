import React, { useState } from 'react';
import { RiskCalculationType } from './types';
import MainMenu from './components/MainMenu';
import VaRCalculator from './components/VaRCalculator';
import CRMCalculator from './components/CRMCalculator';
import IRCCalculator from './components/IRCCalculator';
import IDRCalculator from './components/IDRCalculator';

function App() {
  const [selectedCalculation, setSelectedCalculation] = useState<RiskCalculationType | null>(null);

  const handleBack = () => {
    setSelectedCalculation(null);
  };

  const renderCalculator = () => {
    switch (selectedCalculation) {
      case 'var':
        return <VaRCalculator onBack={handleBack} />;
      case 'crm':
        return <CRMCalculator onBack={handleBack} />;
      case 'irc':
        return <IRCCalculator onBack={handleBack} />;
      case 'idr':
        return <IDRCalculator onBack={handleBack} />;
      default:
        return <MainMenu onSelectCalculation={setSelectedCalculation} />;
    }
  };

  return (
    <div className="App">
      {renderCalculator()}
    </div>
  );
}

export default App;