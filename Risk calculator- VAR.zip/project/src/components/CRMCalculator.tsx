import React, { useState } from 'react';
import { ArrowLeft, Calculator, BarChart3, AlertCircle, Plus, Minus } from 'lucide-react';
import { CRMInputs } from '../types';
import { calculateCRM, formatCurrency } from '../utils/calculations';
import Footer from './Footer';

interface CRMCalculatorProps {
  onBack: () => void;
}

const CRMCalculator: React.FC<CRMCalculatorProps> = ({ onBack }) => {
  const [inputs, setInputs] = useState<CRMInputs>({
    totalExposure: 1000000,
    riskFactors: [0.1, 0.15, 0.08],
    timeHorizon: 10,
    correlationCoefficients: [0.3, 0.5, 0.2]
  });
  const [result, setResult] = useState<number | null>(null);
  const [errors, setErrors] = useState<string[]>([]);

  const handleInputChange = (field: keyof CRMInputs, value: number) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayChange = (field: 'riskFactors' | 'correlationCoefficients', index: number, value: number) => {
    setInputs(prev => ({
      ...prev,
      [field]: prev[field].map((item, i) => i === index ? value : item)
    }));
  };

  const addArrayItem = (field: 'riskFactors' | 'correlationCoefficients') => {
    setInputs(prev => ({
      ...prev,
      [field]: [...prev[field], field === 'riskFactors' ? 0.1 : 0.3]
    }));
  };

  const removeArrayItem = (field: 'riskFactors' | 'correlationCoefficients', index: number) => {
    setInputs(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  const handleCalculate = () => {
    const newErrors: string[] = [];

    if (inputs.totalExposure <= 0) {
      newErrors.push('Total exposure must be positive');
    }

    if (inputs.riskFactors.length === 0) {
      newErrors.push('At least one risk factor is required');
    }

    if (inputs.correlationCoefficients.length === 0) {
      newErrors.push('At least one correlation coefficient is required');
    }

    if (inputs.timeHorizon <= 0) {
      newErrors.push('Time horizon must be positive');
    }

    if (inputs.riskFactors.some(factor => factor <= 0)) {
      newErrors.push('All risk factors must be positive');
    }

    if (inputs.correlationCoefficients.some(corr => corr < -1 || corr > 1)) {
      newErrors.push('Correlation coefficients must be between -1 and 1');
    }

    if (newErrors.length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors([]);
    const crmResult = calculateCRM(inputs);
    setResult(crmResult);
  };

  const handleReset = () => {
    setInputs({
      totalExposure: 1000000,
      riskFactors: [0.1, 0.15, 0.08],
      timeHorizon: 10,
      correlationCoefficients: [0.3, 0.5, 0.2]
    });
    setResult(null);
    setErrors([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Main Menu</span>
          </button>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Comprehensive Risk Measure (CRM)</h1>
          <p className="text-gray-600">Assess comprehensive risk across multiple factors and correlations</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <BarChart3 className="w-5 h-5 mr-2" />
              Risk Parameters
            </h2>

            {/* Total Exposure */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Total Exposure ($)
              </label>
              <input
                type="number"
                value={inputs.totalExposure}
                onChange={(e) => handleInputChange('totalExposure', parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter total exposure"
              />
            </div>

            {/* Time Horizon */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Time Horizon (days)
              </label>
              <input
                type="number"
                value={inputs.timeHorizon}
                onChange={(e) => handleInputChange('timeHorizon', parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter time horizon"
              />
            </div>

            {/* Risk Factors */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  Risk Factors
                </label>
                <button
                  onClick={() => addArrayItem('riskFactors')}
                  className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Factor</span>
                </button>
              </div>
              {inputs.riskFactors.map((factor, index) => (
                <div key={index} className="flex items-center space-x-2 mb-2">
                  <input
                    type="number"
                    step="0.01"
                    value={factor}
                    onChange={(e) => handleArrayChange('riskFactors', index, parseFloat(e.target.value) || 0)}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Risk factor"
                  />
                  <button
                    onClick={() => removeArrayItem('riskFactors', index)}
                    className="text-red-500 hover:text-red-700 p-1"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Correlation Coefficients */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  Correlation Coefficients
                </label>
                <button
                  onClick={() => addArrayItem('correlationCoefficients')}
                  className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Correlation</span>
                </button>
              </div>
              {inputs.correlationCoefficients.map((corr, index) => (
                <div key={index} className="flex items-center space-x-2 mb-2">
                  <input
                    type="number"
                    step="0.01"
                    min="-1"
                    max="1"
                    value={corr}
                    onChange={(e) => handleArrayChange('correlationCoefficients', index, parseFloat(e.target.value) || 0)}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Correlation (-1 to 1)"
                  />
                  <button
                    onClick={() => removeArrayItem('correlationCoefficients', index)}
                    className="text-red-500 hover:text-red-700 p-1"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <button
                onClick={handleCalculate}
                className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
              >
                <Calculator className="w-5 h-5 mr-2" />
                Calculate CRM
              </button>
              <button
                onClick={handleReset}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Reset
              </button>
            </div>

            {/* Errors */}
            {errors.length > 0 && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center mb-2">
                  <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
                  <span className="text-red-700 font-medium">Please fix the following errors:</span>
                </div>
                <ul className="text-red-600 text-sm space-y-1">
                  {errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Results Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Results</h2>
            
            {result !== null ? (
              <div className="space-y-4">
                <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                  <h3 className="text-lg font-semibold text-green-900 mb-2">Comprehensive Risk Measure</h3>
                  <p className="text-3xl font-bold text-green-600">{formatCurrency(result)}</p>
                  <p className="text-sm text-green-700 mt-2">
                    Over {inputs.timeHorizon} day time horizon
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Interpretation</h4>
                  <p className="text-gray-700 text-sm">
                    The Comprehensive Risk Measure represents the potential loss considering all risk factors 
                    and their correlations over the specified time horizon. This measure accounts for the 
                    diversification benefits and concentration risks in your portfolio.
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Risk Factors Summary</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Total Exposure:</span>
                      <span className="font-medium ml-2">{formatCurrency(inputs.totalExposure)}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Time Horizon:</span>
                      <span className="font-medium ml-2">{inputs.timeHorizon} days</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Risk Factors:</span>
                      <span className="font-medium ml-2">{inputs.riskFactors.length} factors</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Correlations:</span>
                      <span className="font-medium ml-2">{inputs.correlationCoefficients.length} pairs</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Methodology</h4>
                  <p className="text-gray-700 text-sm">
                    CRM calculation considers the average risk factor magnitude, correlation effects, 
                    and time horizon scaling. The measure provides a comprehensive view of portfolio 
                    risk across multiple dimensions and time periods.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-500 py-12">
                <Calculator className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p>Enter parameters and click "Calculate CRM" to see results</p>
              </div>
            )}
          </div>
        </div>
        
        <Footer />
      </div>
    </div>
  );
};

export default CRMCalculator;