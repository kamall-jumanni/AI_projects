import React from 'react';
import { Calculator, TrendingUp, Shield, AlertTriangle, BarChart3 } from 'lucide-react';
import { RiskCalculationType } from '../types';
import Footer from './Footer';

interface MainMenuProps {
  onSelectCalculation: (type: RiskCalculationType) => void;
}

const MainMenu: React.FC<MainMenuProps> = ({ onSelectCalculation }) => {
  const menuItems = [
    {
      id: 'var' as RiskCalculationType,
      title: 'Value at Risk (VaR)',
      description: 'Calculate potential losses using Historical, Variance-Covariance, or Monte Carlo methods',
      icon: TrendingUp,
      color: 'bg-blue-500'
    },
    {
      id: 'crm' as RiskCalculationType,
      title: 'Comprehensive Risk Measure (CRM)',
      description: 'Assess comprehensive risk across multiple factors and correlations',
      icon: BarChart3,
      color: 'bg-green-500'
    },
    {
      id: 'irc' as RiskCalculationType,
      title: 'Incremental Risk Charge (IRC)',
      description: 'Calculate incremental risk charge based on portfolio cash flows and default probabilities',
      icon: Shield,
      color: 'bg-purple-500'
    },
    {
      id: 'idr' as RiskCalculationType,
      title: 'Incremental Default Risk (IDR)',
      description: 'Measure incremental default risk using historical default rates and loss given default',
      icon: AlertTriangle,
      color: 'bg-orange-500'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-xl mb-4">
            <Calculator className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Basel III Risk Calculator</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive risk assessment tools compliant with Basel III framework. 
            Select a calculation method to begin your risk analysis.
          </p>
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {menuItems.map((item) => {
            const IconComponent = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onSelectCalculation(item.id)}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 text-left group hover:scale-105 border border-gray-100"
              >
                <div className="flex items-start space-x-4">
                  <div className={`${item.color} p-3 rounded-xl group-hover:scale-110 transition-transform duration-300`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="mt-16 text-center">
          <p className="text-gray-500 text-sm mb-4">
            Built for Basel III compliance • Accurate risk calculations • Production-ready
          </p>
        </div>
        
        <Footer />
      </div>
    </div>
  );
};

export default MainMenu;