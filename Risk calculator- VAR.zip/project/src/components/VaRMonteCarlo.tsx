import React, { useState } from 'react';
import { ArrowLeft, Calculator, Zap, AlertCircle, RefreshCw } from 'lucide-react';
import { VaRMonteCarloInputs } from '../types';
import { calculateVaRMonteCarlo, formatCurrency, formatPercentage } from '../utils/calculations';
import Footer from './Footer';

interface VaRMonteCarloProps {
  onBack: () => void;
}

const VaRMonteCarlo: React.FC<VaRMonteCarloProps> = ({ onBack }) => {
  const [inputs, setInputs] = useState<VaRMonteCarloInputs>({
    averageReturn: 0.08,
    volatility: 0.15,
    confidenceLevel: 95,
    portfolioValue: 1000000,
    timeHorizon: 1,
    numSimulations: 10000
  });
  const [result, setResult] = useState<number | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const [isCalculating, setIsCalculating] = useState(false);

  const handleInputChange = (field: keyof VaRMonteCarloInputs, value: number) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const handleCalculate = async () => {
    const newErrors: string[] = [];

    if (inputs.portfolioValue <= 0) {
      newErrors.push('Portfolio value must be positive');
    }

    if (inputs.volatility <= 0) {
      newErrors.push('Volatility must be positive');
    }

    if (inputs.confidenceLevel < 90 || inputs.confidenceLevel > 99.9) {
      newErrors.push('Confidence level must be between 90% and 99.9%');
    }

    if (inputs.timeHorizon <= 0) {
      newErrors.push('Time horizon must be positive');
    }

    if (inputs.numSimulations < 1000 || inputs.numSimulations > 100000) {
      newErrors.push('Number of simulations must be between 1,000 and 100,000');
    }

    if (newErrors.length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors([]);
    setIsCalculating(true);

    // Add a small delay to show the loading state
    setTimeout(() => {
      const varResult = calculateVaRMonteCarlo(inputs);
      setResult(varResult);
      setIsCalculating(false);
    }, 1000);
  };

  const handleReset = () => {
    setInputs({
      averageReturn: 0.08,
      volatility: 0.15,
      confidenceLevel: 95,
      portfolioValue: 1000000,
      timeHorizon: 1,
      numSimulations: 10000
    });
    setResult(null);
    setErrors([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to VaR Methods</span>
          </button>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Monte Carlo VaR Method</h1>
          <p className="text-gray-600">Stochastic simulation approach for complex risk assessment</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <Zap className="w-5 h-5 mr-2" />
              Simulation Parameters
            </h2>

            {/* Portfolio Value */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Portfolio Value ($)
              </label>
              <input
                type="number"
                value={inputs.portfolioValue}
                onChange={(e) => handleInputChange('portfolioValue', parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter portfolio value"
              />
            </div>

            {/* Average Return */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Average Annual Return (decimal)
              </label>
              <input
                type="number"
                step="0.01"
                value={inputs.averageReturn}
                onChange={(e) => handleInputChange('averageReturn', parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., 0.08 for 8%"
              />
              <p className="text-xs text-gray-500 mt-1">
                Current: {formatPercentage(inputs.averageReturn)} annual return
              </p>
            </div>

            {/* Volatility */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Volatility (decimal)
              </label>
              <input
                type="number"
                step="0.01"
                value={inputs.volatility}
                onChange={(e) => handleInputChange('volatility', parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., 0.15 for 15%"
              />
              <p className="text-xs text-gray-500 mt-1">
                Current: {formatPercentage(inputs.volatility)} volatility
              </p>
            </div>

            {/* Confidence Level */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Confidence Level (%)
              </label>
              <select
                value={inputs.confidenceLevel}
                onChange={(e) => handleInputChange('confidenceLevel', parseFloat(e.target.value))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value={90}>90%</option>
                <option value={95}>95%</option>
                <option value={99}>99%</option>
                <option value={99.9}>99.9%</option>
              </select>
            </div>

            {/* Time Horizon */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Time Horizon (days)
              </label>
              <input
                type="number"
                value={inputs.timeHorizon}
                onChange={(e) => handleInputChange('timeHorizon', parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter time horizon"
              />
            </div>

            {/* Number of Simulations */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Number of Simulations
              </label>
              <select
                value={inputs.numSimulations}
                onChange={(e) => handleInputChange('numSimulations', parseInt(e.target.value))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value={1000}>1,000</option>
                <option value={5000}>5,000</option>
                <option value={10000}>10,000</option>
                <option value={50000}>50,000</option>
                <option value={100000}>100,000</option>
              </select>
              <p className="text-xs text-gray-500 mt-1">
                More simulations = higher accuracy but slower computation
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <button
                onClick={handleCalculate}
                disabled={isCalculating}
                className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isCalculating ? (
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                ) : (
                  <Calculator className="w-5 h-5 mr-2" />
                )}
                {isCalculating ? 'Simulating...' : 'Calculate VaR'}
              </button>
              <button
                onClick={handleReset}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Reset
              </button>
            </div>

            {/* Errors */}
            {errors.length > 0 && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center mb-2">
                  <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
                  <span className="text-red-700 font-medium">Please fix the following errors:</span>
                </div>
                <ul className="text-red-600 text-sm space-y-1">
                  {errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Results Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Results</h2>
            
            {result !== null ? (
              <div className="space-y-4">
                <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                  <h3 className="text-lg font-semibold text-blue-900 mb-2">Value at Risk (VaR)</h3>
                  <p className="text-3xl font-bold text-blue-600">{formatCurrency(result)}</p>
                  <p className="text-sm text-blue-700 mt-2">
                    At {inputs.confidenceLevel}% confidence level over {inputs.timeHorizon} day(s)
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Interpretation</h4>
                  <p className="text-gray-700 text-sm">
                    Based on {inputs.numSimulations.toLocaleString()} Monte Carlo simulations, there is a {inputs.confidenceLevel}% probability that the portfolio will not lose more than {formatCurrency(result)} over the next {inputs.timeHorizon} day(s).
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Simulation Parameters</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Average Return:</span>
                      <span className="font-medium ml-2">{formatPercentage(inputs.averageReturn)}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Volatility:</span>
                      <span className="font-medium ml-2">{formatPercentage(inputs.volatility)}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Simulations:</span>
                      <span className="font-medium ml-2">{inputs.numSimulations.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Time Horizon:</span>
                      <span className="font-medium ml-2">{inputs.timeHorizon} day(s)</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Methodology</h4>
                  <p className="text-gray-700 text-sm">
                    Monte Carlo simulation generates thousands of random scenarios for portfolio returns, 
                    creating an empirical distribution to calculate VaR. This method is particularly useful 
                    for portfolios with non-linear risk characteristics.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-500 py-12">
                <Calculator className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p>Enter parameters and click "Calculate VaR" to see results</p>
              </div>
            )}
          </div>
        </div>
        
        <Footer />
      </div>
    </div>
  );
};

export default VaRMonteCarlo;