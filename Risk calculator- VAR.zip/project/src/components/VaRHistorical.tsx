import React, { useState } from 'react';
import { ArrowLeft, Calculator, Upload, AlertCircle } from 'lucide-react';
import { VaRHistoricalInputs } from '../types';
import { calculateVaRHistorical, formatCurrency } from '../utils/calculations';
import Footer from './Footer';

interface VaRHistoricalProps {
  onBack: () => void;
}

const VaRHistorical: React.FC<VaRHistoricalProps> = ({ onBack }) => {
  const [inputs, setInputs] = useState<VaRHistoricalInputs>({
    historicalPrices: [],
    confidenceLevel: 95,
    portfolioValue: 1000000
  });
  const [priceInput, setPriceInput] = useState('');
  const [result, setResult] = useState<number | null>(null);
  const [errors, setErrors] = useState<string[]>([]);

  const handleAddPrice = () => {
    const price = parseFloat(priceInput);
    if (!isNaN(price) && price > 0) {
      setInputs(prev => ({
        ...prev,
        historicalPrices: [...prev.historicalPrices, price]
      }));
      setPriceInput('');
    }
  };

  const handleRemovePrice = (index: number) => {
    setInputs(prev => ({
      ...prev,
      historicalPrices: prev.historicalPrices.filter((_, i) => i !== index)
    }));
  };

  const handleCalculate = () => {
    const newErrors: string[] = [];

    if (inputs.historicalPrices.length < 30) {
      newErrors.push('At least 30 historical prices are required for reliable VaR calculation');
    }

    if (inputs.portfolioValue <= 0) {
      newErrors.push('Portfolio value must be positive');
    }

    if (inputs.confidenceLevel < 90 || inputs.confidenceLevel > 99.9) {
      newErrors.push('Confidence level must be between 90% and 99.9%');
    }

    if (newErrors.length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors([]);
    const varResult = calculateVaRHistorical(inputs);
    setResult(varResult);
  };

  const handleReset = () => {
    setInputs({
      historicalPrices: [],
      confidenceLevel: 95,
      portfolioValue: 1000000
    });
    setPriceInput('');
    setResult(null);
    setErrors([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to VaR Methods</span>
          </button>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Historical VaR Method</h1>
          <p className="text-gray-600">Calculate VaR using historical price movements</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <Upload className="w-5 h-5 mr-2" />
              Input Parameters
            </h2>

            {/* Portfolio Value */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Portfolio Value ($)
              </label>
              <input
                type="number"
                value={inputs.portfolioValue}
                onChange={(e) => setInputs(prev => ({ ...prev, portfolioValue: parseFloat(e.target.value) || 0 }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter portfolio value"
              />
            </div>

            {/* Confidence Level */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Confidence Level (%)
              </label>
              <select
                value={inputs.confidenceLevel}
                onChange={(e) => setInputs(prev => ({ ...prev, confidenceLevel: parseFloat(e.target.value) }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value={90}>90%</option>
                <option value={95}>95%</option>
                <option value={99}>99%</option>
                <option value={99.9}>99.9%</option>
              </select>
            </div>

            {/* Historical Prices */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Historical Prices ({inputs.historicalPrices.length} prices)
              </label>
              <div className="flex space-x-2 mb-3">
                <input
                  type="number"
                  value={priceInput}
                  onChange={(e) => setPriceInput(e.target.value)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter price"
                  onKeyPress={(e) => e.key === 'Enter' && handleAddPrice()}
                />
                <button
                  onClick={handleAddPrice}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Add
                </button>
              </div>
              
              {inputs.historicalPrices.length > 0 && (
                <div className="max-h-40 overflow-y-auto border border-gray-200 rounded-lg p-3">
                  <div className="grid grid-cols-4 gap-2">
                    {inputs.historicalPrices.map((price, index) => (
                      <div key={index} className="flex items-center justify-between bg-gray-50 px-2 py-1 rounded text-sm">
                        <span>${price.toFixed(2)}</span>
                        <button
                          onClick={() => handleRemovePrice(index)}
                          className="text-red-500 hover:text-red-700 ml-1"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <button
                onClick={handleCalculate}
                className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
              >
                <Calculator className="w-5 h-5 mr-2" />
                Calculate VaR
              </button>
              <button
                onClick={handleReset}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Reset
              </button>
            </div>

            {/* Errors */}
            {errors.length > 0 && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center mb-2">
                  <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
                  <span className="text-red-700 font-medium">Please fix the following errors:</span>
                </div>
                <ul className="text-red-600 text-sm space-y-1">
                  {errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Results Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Results</h2>
            
            {result !== null ? (
              <div className="space-y-4">
                <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                  <h3 className="text-lg font-semibold text-blue-900 mb-2">Value at Risk (VaR)</h3>
                  <p className="text-3xl font-bold text-blue-600">{formatCurrency(result)}</p>
                  <p className="text-sm text-blue-700 mt-2">
                    At {inputs.confidenceLevel}% confidence level
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Interpretation</h4>
                  <p className="text-gray-700 text-sm">
                    There is a {inputs.confidenceLevel}% probability that the portfolio will not lose more than {formatCurrency(result)} in the next trading day, based on historical price movements.
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Methodology</h4>
                  <p className="text-gray-700 text-sm">
                    Historical VaR uses {inputs.historicalPrices.length} historical price points to calculate empirical returns distribution and determine the {inputs.confidenceLevel}th percentile loss.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-500 py-12">
                <Calculator className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p>Enter parameters and click "Calculate VaR" to see results</p>
              </div>
            )}
          </div>
        </div>
        
        <Footer />
      </div>
    </div>
  );
};

export default VaRHistorical;