import React from 'react';

const Footer: React.FC = () => {
  return (
    <div className="mt-16 text-center pb-6">
      <p className="text-red-600 font-bold text-lg">
        by Kamall Jumanni
      </p>
    </div>
  );
};

export default Footer;