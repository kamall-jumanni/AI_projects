import React, { useState } from 'react';
import { ArrowLeft, Calculator, TrendingUp, BarChart, Zap } from 'lucide-react';
import { VaRMethodType } from '../types';
import VaRHistorical from './VaRHistorical';
import VaRVarianceCovariance from './VaRVarianceCovariance';
import VaRMonteCarlo from './VaRMonteCarlo';
import Footer from './Footer';

interface VaRCalculatorProps {
  onBack: () => void;
}

const VaRCalculator: React.FC<VaRCalculatorProps> = ({ onBack }) => {
  const [selectedMethod, setSelectedMethod] = useState<VaRMethodType | null>(null);

  const methods = [
    {
      id: 'historical' as VaRMethodType,
      title: 'Historical Method',
      description: 'Calculate VaR using historical price movements and empirical distribution',
      icon: TrendingUp,
      color: 'bg-blue-500'
    },
    {
      id: 'variance-covariance' as VaRMethodType,
      title: 'Variance-Covariance Method',
      description: 'Parametric approach assuming normal distribution of returns',
      icon: BarChart,
      color: 'bg-green-500'
    },
    {
      id: 'monte-carlo' as VaRMethodType,
      title: 'Monte Carlo Simulation',
      description: 'Stochastic simulation approach for complex portfolios',
      icon: Zap,
      color: 'bg-purple-500'
    }
  ];

  if (selectedMethod) {
    const renderMethodComponent = () => {
      switch (selectedMethod) {
        case 'historical':
          return <VaRHistorical onBack={() => setSelectedMethod(null)} />;
        case 'variance-covariance':
          return <VaRVarianceCovariance onBack={() => setSelectedMethod(null)} />;
        case 'monte-carlo':
          return <VaRMonteCarlo onBack={() => setSelectedMethod(null)} />;
        default:
          return null;
      }
    };

    return renderMethodComponent();
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Main Menu</span>
          </button>
        </div>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-xl mb-4">
            <Calculator className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Value at Risk (VaR)</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Choose a methodology to calculate your portfolio's Value at Risk. 
            Each method offers different approaches to risk assessment.
          </p>
        </div>

        {/* Method Selection */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {methods.map((method) => {
            const IconComponent = method.icon;
            return (
              <button
                key={method.id}
                onClick={() => setSelectedMethod(method.id)}
                className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 text-left group hover:scale-105 border border-gray-100"
              >
                <div className="text-center">
                  <div className={`${method.color} p-4 rounded-xl inline-flex mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                    {method.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {method.description}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
        
        <Footer />
      </div>
    </div>
  );
};

export default VaRCalculator;