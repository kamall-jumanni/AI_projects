import React, { useState } from 'react';
import { ArrowLeft, Calculator, AlertTriangle, AlertCircle, Plus, Minus } from 'lucide-react';
import { IDRInputs } from '../types';
import { calculateIDR, formatCurrency, formatPercentage } from '../utils/calculations';
import Footer from './Footer';

interface IDRCalculatorProps {
  onBack: () => void;
}

const IDRCalculator: React.FC<IDRCalculatorProps> = ({ onBack }) => {
  const [inputs, setInputs] = useState<IDRInputs>({
    defaultProbability: 0.05,
    historicalDefaultRates: [0.02, 0.03, 0.025, 0.04, 0.035],
    lossGivenDefault: 0.6,
    exposure: 1000000
  });
  const [historicalInput, setHistoricalInput] = useState('');
  const [result, setResult] = useState<number | null>(null);
  const [errors, setErrors] = useState<string[]>([]);

  const handleInputChange = (field: keyof IDRInputs, value: number | number[]) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const handleAddHistoricalRate = () => {
    const rate = parseFloat(historicalInput);
    if (!isNaN(rate) && rate >= 0 && rate <= 1) {
      setInputs(prev => ({
        ...prev,
        historicalDefaultRates: [...prev.historicalDefaultRates, rate]
      }));
      setHistoricalInput('');
    }
  };

  const handleRemoveHistoricalRate = (index: number) => {
    setInputs(prev => ({
      ...prev,
      historicalDefaultRates: prev.historicalDefaultRates.filter((_, i) => i !== index)
    }));
  };

  const handleCalculate = () => {
    const newErrors: string[] = [];

    if (inputs.defaultProbability < 0 || inputs.defaultProbability > 1) {
      newErrors.push('Default probability must be between 0 and 1');
    }

    if (inputs.lossGivenDefault < 0 || inputs.lossGivenDefault > 1) {
      newErrors.push('Loss given default must be between 0 and 1');
    }

    if (inputs.exposure <= 0) {
      newErrors.push('Exposure must be positive');
    }

    if (inputs.historicalDefaultRates.length === 0) {
      newErrors.push('At least one historical default rate is required');
    }

    if (inputs.historicalDefaultRates.some(rate => rate < 0 || rate > 1)) {
      newErrors.push('All historical default rates must be between 0 and 1');
    }

    if (newErrors.length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors([]);
    const idrResult = calculateIDR(inputs);
    setResult(idrResult);
  };

  const handleReset = () => {
    setInputs({
      defaultProbability: 0.05,
      historicalDefaultRates: [0.02, 0.03, 0.025, 0.04, 0.035],
      lossGivenDefault: 0.6,
      exposure: 1000000
    });
    setHistoricalInput('');
    setResult(null);
    setErrors([]);
  };

  const avgHistoricalRate = inputs.historicalDefaultRates.length > 0 
    ? inputs.historicalDefaultRates.reduce((sum, rate) => sum + rate, 0) / inputs.historicalDefaultRates.length
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Main Menu</span>
          </button>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Incremental Default Risk (IDR)</h1>
          <p className="text-gray-600">Measure incremental default risk using historical default rates and loss given default</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Default Risk Parameters
            </h2>

            {/* Current Default Probability */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Current Default Probability
              </label>
              <input
                type="number"
                step="0.001"
                min="0"
                max="1"
                value={inputs.defaultProbability}
                onChange={(e) => handleInputChange('defaultProbability', parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., 0.05 for 5%"
              />
              <p className="text-xs text-gray-500 mt-1">
                Current: {formatPercentage(inputs.defaultProbability)}
              </p>
            </div>

            {/* Loss Given Default */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Loss Given Default (LGD)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                max="1"
                value={inputs.lossGivenDefault}
                onChange={(e) => handleInputChange('lossGivenDefault', parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., 0.6 for 60%"
              />
              <p className="text-xs text-gray-500 mt-1">
                Current: {formatPercentage(inputs.lossGivenDefault)}
              </p>
            </div>

            {/* Exposure */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Exposure ($)
              </label>
              <input
                type="number"
                value={inputs.exposure}
                onChange={(e) => handleInputChange('exposure', parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter exposure amount"
              />
            </div>

            {/* Historical Default Rates */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Historical Default Rates ({inputs.historicalDefaultRates.length} entries)
              </label>
              <div className="flex space-x-2 mb-3">
                <input
                  type="number"
                  step="0.001"
                  min="0"
                  max="1"
                  value={historicalInput}
                  onChange={(e) => setHistoricalInput(e.target.value)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter historical rate"
                  onKeyPress={(e) => e.key === 'Enter' && handleAddHistoricalRate()}
                />
                <button
                  onClick={handleAddHistoricalRate}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              
              {inputs.historicalDefaultRates.length > 0 && (
                <div className="max-h-40 overflow-y-auto border border-gray-200 rounded-lg p-3">
                  <div className="grid grid-cols-2 gap-2">
                    {inputs.historicalDefaultRates.map((rate, index) => (
                      <div key={index} className="flex items-center justify-between bg-gray-50 px-3 py-2 rounded text-sm">
                        <span>{formatPercentage(rate)}</span>
                        <button
                          onClick={() => handleRemoveHistoricalRate(index)}
                          className="text-red-500 hover:text-red-700 ml-2"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {avgHistoricalRate > 0 && (
                <p className="text-xs text-gray-500 mt-2">
                  Average historical default rate: {formatPercentage(avgHistoricalRate)}
                </p>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <button
                onClick={handleCalculate}
                className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
              >
                <Calculator className="w-5 h-5 mr-2" />
                Calculate IDR
              </button>
              <button
                onClick={handleReset}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Reset
              </button>
            </div>

            {/* Errors */}
            {errors.length > 0 && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center mb-2">
                  <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
                  <span className="text-red-700 font-medium">Please fix the following errors:</span>
                </div>
                <ul className="text-red-600 text-sm space-y-1">
                  {errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Results Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Results</h2>
            
            {result !== null ? (
              <div className="space-y-4">
                <div className="bg-orange-50 p-6 rounded-lg border border-orange-200">
                  <h3 className="text-lg font-semibold text-orange-900 mb-2">Incremental Default Risk</h3>
                  <p className="text-3xl font-bold text-orange-600">{formatCurrency(result)}</p>
                  <p className="text-sm text-orange-700 mt-2">
                    Additional risk above historical average
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Risk Comparison</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Current Default Prob:</span>
                      <span className="font-medium ml-2">{formatPercentage(inputs.defaultProbability)}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Historical Average:</span>
                      <span className="font-medium ml-2">{formatPercentage(avgHistoricalRate)}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Incremental PD:</span>
                      <span className="font-medium ml-2">
                        {formatPercentage(Math.max(0, inputs.defaultProbability - avgHistoricalRate))}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-600">Loss Given Default:</span>
                      <span className="font-medium ml-2">{formatPercentage(inputs.lossGivenDefault)}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Interpretation</h4>
                  <p className="text-gray-700 text-sm">
                    The Incremental Default Risk represents the additional expected loss due to the 
                    current default probability being higher than the historical average. This measure 
                    helps identify periods of elevated default risk relative to historical norms.
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Calculation Details</h4>
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Exposure:</span>
                      <span className="font-medium">{formatCurrency(inputs.exposure)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Incremental PD:</span>
                      <span className="font-medium">
                        {formatPercentage(Math.max(0, inputs.defaultProbability - avgHistoricalRate))}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Loss Given Default:</span>
                      <span className="font-medium">{formatPercentage(inputs.lossGivenDefault)}</span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span className="text-gray-600">IDR:</span>
                      <span className="font-medium">{formatCurrency(result)}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Historical Data Summary</h4>
                  <div className="text-sm">
                    <p className="text-gray-700">
                      Based on {inputs.historicalDefaultRates.length} historical observations with 
                      rates ranging from {formatPercentage(Math.min(...inputs.historicalDefaultRates))} to{' '}
                      {formatPercentage(Math.max(...inputs.historicalDefaultRates))}.
                    </p>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Methodology</h4>
                  <p className="text-gray-700 text-sm">
                    IDR = Exposure × max(0, Current PD - Average Historical PD) × Loss Given Default. 
                    This calculation isolates the incremental risk above historical norms.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-500 py-12">
                <Calculator className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p>Enter parameters and click "Calculate IDR" to see results</p>
              </div>
            )}
          </div>
        </div>
        
        <Footer />
      </div>
    </div>
  );
};

export default IDRCalculator;