import React, { useState } from 'react';
import { ArrowLeft, Calculator, Shield, AlertCircle, Plus, Minus } from 'lucide-react';
import { IRCInputs } from '../types';
import { calculateIRC, formatCurrency, formatPercentage } from '../utils/calculations';
import Footer from './Footer';

interface IRCCalculatorProps {
  onBack: () => void;
}

const IRCCalculator: React.FC<IRCCalculatorProps> = ({ onBack }) => {
  const [inputs, setInputs] = useState<IRCInputs>({
    portfolioCashFlows: [100000, 200000, 150000],
    defaultProbabilities: [0.02, 0.03, 0.015],
    recoveryRates: [0.4, 0.35, 0.45],
    timeFrame: 1
  });
  const [result, setResult] = useState<number | null>(null);
  const [errors, setErrors] = useState<string[]>([]);

  const handleInputChange = (field: keyof IRCInputs, value: number) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayChange = (field: 'portfolioCashFlows' | 'defaultProbabilities' | 'recoveryRates', index: number, value: number) => {
    setInputs(prev => ({
      ...prev,
      [field]: prev[field].map((item, i) => i === index ? value : item)
    }));
  };

  const addPosition = () => {
    setInputs(prev => ({
      ...prev,
      portfolioCashFlows: [...prev.portfolioCashFlows, 100000],
      defaultProbabilities: [...prev.defaultProbabilities, 0.02],
      recoveryRates: [...prev.recoveryRates, 0.4]
    }));
  };

  const removePosition = (index: number) => {
    setInputs(prev => ({
      ...prev,
      portfolioCashFlows: prev.portfolioCashFlows.filter((_, i) => i !== index),
      defaultProbabilities: prev.defaultProbabilities.filter((_, i) => i !== index),
      recoveryRates: prev.recoveryRates.filter((_, i) => i !== index)
    }));
  };

  const handleCalculate = () => {
    const newErrors: string[] = [];

    if (inputs.portfolioCashFlows.length === 0) {
      newErrors.push('At least one portfolio position is required');
    }

    if (inputs.portfolioCashFlows.length !== inputs.defaultProbabilities.length ||
        inputs.portfolioCashFlows.length !== inputs.recoveryRates.length) {
      newErrors.push('Number of cash flows, default probabilities, and recovery rates must match');
    }

    if (inputs.timeFrame <= 0) {
      newErrors.push('Time frame must be positive');
    }

    if (inputs.defaultProbabilities.some(pd => pd < 0 || pd > 1)) {
      newErrors.push('Default probabilities must be between 0 and 1');
    }

    if (inputs.recoveryRates.some(rr => rr < 0 || rr > 1)) {
      newErrors.push('Recovery rates must be between 0 and 1');
    }

    if (newErrors.length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors([]);
    const ircResult = calculateIRC(inputs);
    setResult(ircResult);
  };

  const handleReset = () => {
    setInputs({
      portfolioCashFlows: [100000, 200000, 150000],
      defaultProbabilities: [0.02, 0.03, 0.015],
      recoveryRates: [0.4, 0.35, 0.45],
      timeFrame: 1
    });
    setResult(null);
    setErrors([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Main Menu</span>
          </button>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Incremental Risk Charge (IRC)</h1>
          <p className="text-gray-600">Calculate incremental risk charge based on portfolio cash flows and default probabilities</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <Shield className="w-5 h-5 mr-2" />
              Portfolio Parameters
            </h2>

            {/* Time Frame */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Time Frame (years)
              </label>
              <input
                type="number"
                step="0.1"
                value={inputs.timeFrame}
                onChange={(e) => handleInputChange('timeFrame', parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter time frame"
              />
            </div>

            {/* Portfolio Positions */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <label className="block text-sm font-medium text-gray-700">
                  Portfolio Positions
                </label>
                <button
                  onClick={addPosition}
                  className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Position</span>
                </button>
              </div>

              {inputs.portfolioCashFlows.map((_, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4 mb-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-gray-900">Position {index + 1}</h4>
                    <button
                      onClick={() => removePosition(index)}
                      className="text-red-500 hover:text-red-700 p-1"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">
                        Cash Flow ($)
                      </label>
                      <input
                        type="number"
                        value={inputs.portfolioCashFlows[index]}
                        onChange={(e) => handleArrayChange('portfolioCashFlows', index, parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        placeholder="Cash flow"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">
                        Default Probability
                      </label>
                      <input
                        type="number"
                        step="0.001"
                        min="0"
                        max="1"
                        value={inputs.defaultProbabilities[index]}
                        onChange={(e) => handleArrayChange('defaultProbabilities', index, parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        placeholder="0.02"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        {formatPercentage(inputs.defaultProbabilities[index])}
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">
                        Recovery Rate
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        max="1"
                        value={inputs.recoveryRates[index]}
                        onChange={(e) => handleArrayChange('recoveryRates', index, parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        placeholder="0.4"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        {formatPercentage(inputs.recoveryRates[index])}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <button
                onClick={handleCalculate}
                className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
              >
                <Calculator className="w-5 h-5 mr-2" />
                Calculate IRC
              </button>
              <button
                onClick={handleReset}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Reset
              </button>
            </div>

            {/* Errors */}
            {errors.length > 0 && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center mb-2">
                  <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
                  <span className="text-red-700 font-medium">Please fix the following errors:</span>
                </div>
                <ul className="text-red-600 text-sm space-y-1">
                  {errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Results Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Results</h2>
            
            {result !== null ? (
              <div className="space-y-4">
                <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
                  <h3 className="text-lg font-semibold text-purple-900 mb-2">Incremental Risk Charge</h3>
                  <p className="text-3xl font-bold text-purple-600">{formatCurrency(result)}</p>
                  <p className="text-sm text-purple-700 mt-2">
                    Over {inputs.timeFrame} year time frame
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Interpretation</h4>
                  <p className="text-gray-700 text-sm">
                    The Incremental Risk Charge represents the additional capital required to cover 
                    the risk of default and migration events in the portfolio. This measure considers 
                    the probability of default, loss given default, and exposure for each position.
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Portfolio Summary</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Total Positions:</span>
                      <span className="font-medium ml-2">{inputs.portfolioCashFlows.length}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Total Exposure:</span>
                      <span className="font-medium ml-2">
                        {formatCurrency(inputs.portfolioCashFlows.reduce((sum, cf) => sum + cf, 0))}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-600">Avg Default Prob:</span>
                      <span className="font-medium ml-2">
                        {formatPercentage(inputs.defaultProbabilities.reduce((sum, pd) => sum + pd, 0) / inputs.defaultProbabilities.length)}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-600">Avg Recovery Rate:</span>
                      <span className="font-medium ml-2">
                        {formatPercentage(inputs.recoveryRates.reduce((sum, rr) => sum + rr, 0) / inputs.recoveryRates.length)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Position Breakdown</h4>
                  <div className="space-y-2 text-sm">
                    {inputs.portfolioCashFlows.map((cf, index) => (
                      <div key={index} className="flex justify-between items-center py-1 border-b border-gray-200 last:border-b-0">
                        <span className="text-gray-600">Position {index + 1}:</span>
                        <span className="font-medium">{formatCurrency(cf)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Methodology</h4>
                  <p className="text-gray-700 text-sm">
                    IRC is calculated as the sum of expected losses across all positions, where each 
                    position's expected loss equals: Cash Flow × Default Probability × Loss Given Default (1 - Recovery Rate) × Time Frame.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-500 py-12">
                <Calculator className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p>Enter parameters and click "Calculate IRC" to see results</p>
              </div>
            )}
          </div>
        </div>
        
        <Footer />
      </div>
    </div>
  );
};

export default IRCCalculator;