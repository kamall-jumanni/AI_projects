import { 
  VaRHistoricalInputs, 
  VaRVarianceCovarianceInputs, 
  VaRMonteCarloInputs,
  CRMInputs,
  IRCInputs,
  IDRInputs
} from '../types';

export const calculateVaRHistorical = (inputs: VaRHistoricalInputs): number => {
  const { historicalPrices, confidenceLevel, portfolioValue } = inputs;
  
  // Calculate returns
  const returns = [];
  for (let i = 1; i < historicalPrices.length; i++) {
    const returnRate = (historicalPrices[i] - historicalPrices[i - 1]) / historicalPrices[i - 1];
    returns.push(returnRate);
  }
  
  // Sort returns in ascending order
  returns.sort((a, b) => a - b);
  
  // Find percentile
  const percentileIndex = Math.floor((1 - confidenceLevel / 100) * returns.length);
  const percentileReturn = returns[percentileIndex];
  
  // Calculate VaR
  return Math.abs(percentileReturn * portfolioValue);
};

export const calculateVaRVarianceCovariance = (inputs: VaRVarianceCovarianceInputs): number => {
  const { averageReturn, standardDeviation, confidenceLevel, portfolioValue, timeHorizon } = inputs;
  
  // Z-score for confidence level
  const zScore = getZScore(confidenceLevel);
  
  // Calculate VaR
  const expectedReturn = averageReturn * timeHorizon;
  const portfolioStdDev = standardDeviation * Math.sqrt(timeHorizon);
  
  return Math.abs((expectedReturn - zScore * portfolioStdDev) * portfolioValue);
};

export const calculateVaRMonteCarlo = (inputs: VaRMonteCarloInputs): number => {
  const { averageReturn, volatility, confidenceLevel, portfolioValue, timeHorizon, numSimulations } = inputs;
  
  const simulations = [];
  
  for (let i = 0; i < numSimulations; i++) {
    // Generate random normal variable
    const randomNormal = generateRandomNormal();
    
    // Calculate portfolio value change
    const portfolioReturn = averageReturn * timeHorizon + volatility * Math.sqrt(timeHorizon) * randomNormal;
    const portfolioChange = portfolioReturn * portfolioValue;
    
    simulations.push(portfolioChange);
  }
  
  // Sort simulations
  simulations.sort((a, b) => a - b);
  
  // Find percentile
  const percentileIndex = Math.floor((1 - confidenceLevel / 100) * simulations.length);
  
  return Math.abs(simulations[percentileIndex]);
};

export const calculateCRM = (inputs: CRMInputs): number => {
  const { totalExposure, riskFactors, timeHorizon, correlationCoefficients } = inputs;
  
  // Simplified CRM calculation
  const avgRiskFactor = riskFactors.reduce((a, b) => a + b, 0) / riskFactors.length;
  const avgCorrelation = correlationCoefficients.reduce((a, b) => a + b, 0) / correlationCoefficients.length;
  
  return totalExposure * avgRiskFactor * Math.sqrt(timeHorizon) * (1 + avgCorrelation);
};

export const calculateIRC = (inputs: IRCInputs): number => {
  const { portfolioCashFlows, defaultProbabilities, recoveryRates, timeFrame } = inputs;
  
  let totalIRC = 0;
  
  for (let i = 0; i < portfolioCashFlows.length; i++) {
    const cashFlow = portfolioCashFlows[i];
    const pd = defaultProbabilities[i] || 0;
    const recoveryRate = recoveryRates[i] || 0;
    const lgd = 1 - recoveryRate;
    
    totalIRC += cashFlow * pd * lgd * timeFrame;
  }
  
  return totalIRC;
};

export const calculateIDR = (inputs: IDRInputs): number => {
  const { defaultProbability, historicalDefaultRates, lossGivenDefault, exposure } = inputs;
  
  // Calculate average historical default rate
  const avgHistoricalDefault = historicalDefaultRates.reduce((a, b) => a + b, 0) / historicalDefaultRates.length;
  
  // Incremental default risk
  const incrementalPD = Math.max(0, defaultProbability - avgHistoricalDefault);
  
  return exposure * incrementalPD * lossGivenDefault;
};

// Helper functions
const getZScore = (confidenceLevel: number): number => {
  const zScores: { [key: number]: number } = {
    90: 1.282,
    95: 1.645,
    99: 2.326,
    99.9: 3.090
  };
  
  return zScores[confidenceLevel] || 1.645;
};

const generateRandomNormal = (): number => {
  // Box-Muller transformation
  const u1 = Math.random();
  const u2 = Math.random();
  
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
};

export const formatPercentage = (value: number): string => {
  return `${(value * 100).toFixed(2)}%`;
};