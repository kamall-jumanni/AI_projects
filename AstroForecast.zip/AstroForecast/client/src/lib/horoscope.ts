import { format } from 'date-fns';

export interface HoroscopeReading {
  zodiacSign: string;
  date: string;
  daily: string;
  love: string;
  career: string;
  health: string;
  luckyNumber: number;
  luckyColor: string;
  luckyStone: string;
  weeklyOverview: string;
}

export interface LuckyElements {
  number: number;
  color: string;
  stone: string;
}

const horoscopeTemplates = {
  Aries: {
    daily: [
      "Your fiery energy is at its peak today. Take charge of situations that require leadership and bold decisions.",
      "Mars energizes your ambitions today. Channel your competitive spirit into productive endeavors.",
      "A surge of confidence empowers you to tackle challenges head-on. Trust your instincts."
    ],
    love: [
      "Passion ignites in your relationships. Express your feelings openly and honestly.",
      "Your magnetic energy attracts romantic opportunities. Be bold in matters of the heart.",
      "Direct communication strengthens your romantic bonds today."
    ],
    career: [
      "Your competitive nature gives you an edge in professional matters.",
      "Leadership opportunities present themselves. Step up and take charge.",
      "Initiative and quick thinking advance your career goals significantly."
    ],
    health: [
      "Channel your energy into physical activities for optimal wellness.",
      "High-intensity workouts align with your natural fire energy today.",
      "Your vitality is strong. Focus on activities that challenge your body."
    ]
  },
  Taurus: {
    daily: [
      "Stability and patience serve you well today. Focus on building lasting foundations.",
      "Your practical approach to challenges yields steady progress and tangible results.",
      "Comfort and security take priority. Trust in your methodical approach."
    ],
    love: [
      "Sensual pleasures and comfort define your romantic experiences today.",
      "Loyalty and consistency strengthen your relationships. Show your devotion.",
      "Physical affection and quality time deepen your romantic connections."
    ],
    career: [
      "Your practical approach leads to solid financial gains and career stability.",
      "Persistence pays off in professional endeavors. Stay the course.",
      "Your reliability makes you invaluable to colleagues and superiors."
    ],
    health: [
      "Indulge in relaxing activities that nourish your soul and body.",
      "Gentle, consistent exercise routines support your overall well-being.",
      "Focus on nutrition and comfort foods that truly nourish you."
    ]
  },
  Gemini: {
    daily: [
      "Communication flows effortlessly. Share your ideas and connect with others.",
      "Your versatility opens multiple opportunities. Embrace variety in your day.",
      "Mental stimulation and social connections energize your spirit today."
    ],
    love: [
      "Intellectual conversations spark romantic interest and deeper connections.",
      "Variety and spontaneity bring excitement to your love life.",
      "Your wit and charm attract potential partners and delight current ones."
    ],
    career: [
      "Your versatility opens multiple opportunities in professional settings.",
      "Communication skills prove invaluable in advancing your career goals.",
      "Networking and information sharing lead to unexpected opportunities."
    ],
    health: [
      "Mental stimulation keeps you energized and vibrant throughout the day.",
      "Variety in your wellness routine prevents boredom and maintains interest.",
      "Social activities and learning contribute to your overall health."
    ]
  },
  Cancer: {
    daily: [
      "Trust your intuition today. Emotional intelligence guides you to the right decisions.",
      "Your nurturing nature creates harmony in personal and professional relationships.",
      "Home and family connections provide comfort and strength today."
    ],
    love: [
      "Nurturing energy strengthens your closest relationships and romantic bonds.",
      "Emotional depth and vulnerability create intimate connections.",
      "Your caring nature attracts those who appreciate genuine affection."
    ],
    career: [
      "Your empathetic nature creates positive workplace dynamics and collaboration.",
      "Intuitive insights guide you toward the right professional decisions.",
      "Caring leadership style inspires loyalty and dedication in others."
    ],
    health: [
      "Honor your emotional needs for inner balance and overall wellness.",
      "Water activities and gentle exercise soothe your sensitive nature.",
      "Nurturing self-care practices restore your emotional equilibrium."
    ]
  },
  Leo: {
    daily: [
      "Shine brightly and let your creativity take center stage. Others are drawn to your magnetic presence.",
      "Your natural charisma opens doors and creates opportunities for recognition.",
      "Confidence and enthusiasm inspire others to follow your lead today."
    ],
    love: [
      "Romance has a theatrical quality. Grand gestures win hearts and create memories.",
      "Your warmth and generosity make you irresistible to romantic partners.",
      "Creative expressions of love bring joy and passion to relationships."
    ],
    career: [
      "Your natural leadership abilities are recognized and rewarded by superiors.",
      "Creative projects and presentations showcase your talents beautifully.",
      "Confidence in your abilities propels you toward professional success."
    ],
    health: [
      "Joyful activities boost your vitality and confidence throughout the day.",
      "Creative movement and dance energize your body and spirit.",
      "Sunshine and outdoor activities enhance your natural radiance."
    ]
  },
  Virgo: {
    daily: [
      "Attention to detail and methodical planning lead to success in all endeavors.",
      "Your analytical mind identifies solutions others might overlook completely.",
      "Organization and efficiency create order from chaos in every situation."
    ],
    love: [
      "Practical acts of service express your deep affection and commitment.",
      "Your thoughtfulness and attention to detail strengthen romantic bonds.",
      "Genuine care shown through helpful actions speaks louder than words."
    ],
    career: [
      "Your analytical skills solve complex problems efficiently and thoroughly.",
      "Perfectionist tendencies ensure high-quality work that impresses others.",
      "Practical solutions and attention to detail advance your career."
    ],
    health: [
      "Establishing healthy routines supports your overall well-being and vitality.",
      "Detailed health tracking helps you optimize your wellness journey.",
      "Mindful eating and exercise habits yield excellent long-term results."
    ]
  },
  Libra: {
    daily: [
      "Harmony and balance guide your interactions. Seek beauty in all aspects of life.",
      "Your diplomatic nature helps resolve conflicts and create peaceful solutions.",
      "Aesthetic appreciation enhances your environment and mood today."
    ],
    love: [
      "Partnership and cooperation create relationship bliss and mutual satisfaction.",
      "Your charm and grace attract harmonious romantic connections.",
      "Balance between giving and receiving strengthens your love life."
    ],
    career: [
      "Diplomatic skills help you navigate challenging situations with grace.",
      "Collaborative efforts yield better results than solo endeavors today.",
      "Your sense of fairness creates positive workplace relationships."
    ],
    health: [
      "Aesthetic environments contribute to your mental wellness and peace.",
      "Balanced activities that combine beauty and movement suit you well.",
      "Social wellness activities enhance your overall health and happiness."
    ]
  },
  Scorpio: {
    daily: [
      "Deep transformation occurs beneath the surface. Embrace change with courage.",
      "Your intensity and passion drive you toward meaningful accomplishments.",
      "Investigative instincts uncover hidden truths and valuable insights today."
    ],
    love: [
      "Intense emotional connections reach new depths of intimacy and understanding.",
      "Your mysterious allure attracts passionate and devoted partners.",
      "Transformation through love brings profound personal growth."
    ],
    career: [
      "Your investigative nature uncovers hidden opportunities and advantages.",
      "Intense focus and determination lead to breakthrough professional success.",
      "Your ability to see beneath surfaces gives you strategic advantages."
    ],
    health: [
      "Release what no longer serves your highest good and well-being.",
      "Transformative healing practices align with your intense nature.",
      "Deep, regenerative rest supports your powerful energy."
    ]
  },
  Sagittarius: {
    daily: [
      "Adventure calls and wisdom awaits. Expand your horizons through new experiences.",
      "Your optimistic outlook attracts fortunate opportunities and positive people.",
      "Freedom and exploration satisfy your wandering spirit today."
    ],
    love: [
      "Freedom and growth characterize your romantic journey and partnerships.",
      "Adventure shared with loved ones deepens your emotional connections.",
      "Your honesty and optimism attract genuine romantic partners."
    ],
    career: [
      "International connections and higher learning advance your professional goals.",
      "Your vision and enthusiasm inspire others to support your ambitions.",
      "Teaching and sharing knowledge open unexpected career pathways."
    ],
    health: [
      "Outdoor activities and exploration energize your spirit and body.",
      "Adventure sports and travel contribute to your overall wellness.",
      "Freedom of movement and varied activities keep you healthy."
    ]
  },
  Capricorn: {
    daily: [
      "Discipline and determination bring you closer to your long-term goals.",
      "Your practical wisdom guides you through challenges with steady progress.",
      "Responsibility and commitment earn you respect and recognition today."
    ],
    love: [
      "Commitment and responsibility deepen your partnerships and romantic bonds.",
      "Your reliability makes you an attractive and trustworthy partner.",
      "Building solid foundations in love requires patience and dedication."
    ],
    career: [
      "Your ambitious nature attracts recognition from authorities and superiors.",
      "Steady progress toward goals demonstrates your professional competence.",
      "Leadership responsibilities align with your natural organizational abilities."
    ],
    health: [
      "Structure and consistency in self-care yield lasting health results.",
      "Disciplined fitness routines support your long-term wellness goals.",
      "Your methodical approach to health creates sustainable positive habits."
    ]
  },
  Aquarius: {
    daily: [
      "Innovation and originality set you apart. Embrace your unique perspective.",
      "Your humanitarian instincts guide you toward meaningful social contributions.",
      "Unconventional approaches yield surprisingly effective results today."
    ],
    love: [
      "Friendship forms the foundation of lasting romance and meaningful connections.",
      "Your independence attracts partners who appreciate your unique qualities.",
      "Intellectual compatibility creates the strongest romantic bonds."
    ],
    career: [
      "Technological advancement and social causes align with your professional purpose.",
      "Your innovative ideas revolutionize traditional approaches and methods.",
      "Group projects and team collaboration showcase your leadership abilities."
    ],
    health: [
      "Community activities and group fitness enhance your well-being significantly.",
      "Alternative healing methods and innovative wellness approaches benefit you.",
      "Social connections contribute importantly to your mental and physical health."
    ]
  },
  Pisces: {
    daily: [
      "Intuition and compassion guide your path. Trust in the flow of universal energy.",
      "Your empathetic nature creates healing connections with others around you.",
      "Dreams and imagination provide insights that logic cannot reach."
    ],
    love: [
      "Spiritual and emotional connections transcend the ordinary in romantic relationships.",
      "Your compassionate nature attracts soulful and understanding partners.",
      "Romantic idealism inspires beautiful and meaningful love experiences."
    ],
    career: [
      "Creative and healing professions call to your soul and natural abilities.",
      "Your intuitive insights provide valuable guidance in professional decisions.",
      "Artistic talents and empathetic skills open unique career opportunities."
    ],
    health: [
      "Water activities and meditation restore your inner peace and balance.",
      "Gentle, flowing movements align with your sensitive energetic nature.",
      "Spiritual practices and emotional healing support your overall wellness."
    ]
  }
};

const luckyNumbers = [3, 7, 11, 13, 17, 21, 25, 27, 33, 39, 42, 47];
const luckyColors = [
  'Silver', 'Gold', 'Deep Blue', 'Royal Purple', 'Emerald Green', 
  'Crimson Red', 'Pure White', 'Midnight Black', 'Rose Gold', 
  'Turquoise', 'Amber', 'Lavender'
];
const luckyStones = [
  'Amethyst', 'Rose Quartz', 'Citrine', 'Moonstone', 'Turquoise', 
  'Garnet', 'Sapphire', 'Emerald', 'Ruby', 'Opal', 'Topaz', 
  'Aquamarine', 'Peridot', 'Carnelian'
];

function getRandomElement<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)];
}

function getRandomFromArray<T>(array: T[]): T {
  const today = new Date();
  const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
  return array[dayOfYear % array.length];
}

export function generateLuckyElements(): LuckyElements {
  return {
    number: getRandomFromArray(luckyNumbers),
    color: getRandomFromArray(luckyColors),
    stone: getRandomFromArray(luckyStones)
  };
}

export function generateHoroscope(zodiacSign: string): HoroscopeReading {
  const today = new Date();
  const templates = horoscopeTemplates[zodiacSign as keyof typeof horoscopeTemplates] || horoscopeTemplates.Aries;
  
  const lucky = generateLuckyElements();
  
  // Use date-based selection for consistency throughout the day
  const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
  
  return {
    zodiacSign,
    date: format(today, 'EEEE, MMMM do, yyyy'),
    daily: templates.daily[dayOfYear % templates.daily.length],
    love: templates.love[dayOfYear % templates.love.length],
    career: templates.career[dayOfYear % templates.career.length],
    health: templates.health[dayOfYear % templates.health.length],
    luckyNumber: lucky.number,
    luckyColor: lucky.color,
    luckyStone: lucky.stone,
    weeklyOverview: `This week brings transformative energy for ${zodiacSign}. Focus on personal growth and embrace new opportunities that align with your authentic self.`
  };
}

export function generateWeeklyStars(): Array<{ day: string, date: number, stars: number }> {
  const today = new Date();
  const week = [];
  
  for (let i = 0; i < 7; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    
    const dayName = format(date, 'EEE').toUpperCase();
    const dayNumber = date.getDate();
    const stars = Math.floor(Math.random() * 3) + 1; // 1-3 stars
    
    week.push({
      day: dayName,
      date: dayNumber,
      stars
    });
  }
  
  return week;
}
