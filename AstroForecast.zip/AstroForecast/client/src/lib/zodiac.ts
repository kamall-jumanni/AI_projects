export interface ZodiacSign {
  name: string;
  symbol: string;
  element: 'Fire' | 'Earth' | 'Air' | 'Water';
  startDate: string;
  endDate: string;
  description: string;
  traits: string[];
}

export const zodiacSigns: ZodiacSign[] = [
  {
    name: 'Aries',
    symbol: '♈',
    element: 'Fire',
    startDate: 'March 21',
    endDate: 'April 19',
    description: 'The Ram - A cardinal fire sign known for leadership, courage, and pioneering spirit.',
    traits: ['Bold', 'Ambitious', 'Confident', 'Independent', 'Passionate']
  },
  {
    name: 'Taurus',
    symbol: '♉',
    element: 'Earth',
    startDate: 'April 20',
    endDate: 'May 20',
    description: 'The Bull - A fixed earth sign known for stability, reliability, and sensuality.',
    traits: ['Reliable', 'Patient', 'Practical', 'Devoted', 'Stable']
  },
  {
    name: 'Gemini',
    symbol: '♊',
    element: 'Air',
    startDate: 'May 21',
    endDate: 'June 20',
    description: 'The Twins - A mutable air sign known for curiosity, adaptability, and communication.',
    traits: ['Curious', 'Adaptable', 'Communicative', 'Witty', 'Versatile']
  },
  {
    name: 'Cancer',
    symbol: '♋',
    element: 'Water',
    startDate: 'June 21',
    endDate: 'July 22',
    description: 'The Crab - A cardinal water sign known for emotion, intuition, and nurturing nature.',
    traits: ['Nurturing', 'Intuitive', 'Protective', 'Emotional', 'Loyal']
  },
  {
    name: 'Leo',
    symbol: '♌',
    element: 'Fire',
    startDate: 'July 23',
    endDate: 'August 22',
    description: 'The Lion - A fixed fire sign known for creativity, generosity, and natural leadership.',
    traits: ['Confident', 'Generous', 'Creative', 'Dramatic', 'Loyal']
  },
  {
    name: 'Virgo',
    symbol: '♍',
    element: 'Earth',
    startDate: 'August 23',
    endDate: 'September 22',
    description: 'The Virgin - A mutable earth sign known for perfectionism, analysis, and service.',
    traits: ['Analytical', 'Practical', 'Perfectionist', 'Helpful', 'Reliable']
  },
  {
    name: 'Libra',
    symbol: '♎',
    element: 'Air',
    startDate: 'September 23',
    endDate: 'October 22',
    description: 'The Scales - A cardinal air sign known for balance, harmony, and justice.',
    traits: ['Diplomatic', 'Fair', 'Social', 'Charming', 'Peaceful']
  },
  {
    name: 'Scorpio',
    symbol: '♏',
    element: 'Water',
    startDate: 'October 23',
    endDate: 'November 21',
    description: 'The Scorpion - A fixed water sign known for intensity, transformation, and mystery.',
    traits: ['Intense', 'Passionate', 'Mysterious', 'Transformative', 'Loyal']
  },
  {
    name: 'Sagittarius',
    symbol: '♐',
    element: 'Fire',
    startDate: 'November 22',
    endDate: 'December 21',
    description: 'The Archer - A mutable fire sign known for adventure, philosophy, and optimism.',
    traits: ['Adventurous', 'Optimistic', 'Philosophical', 'Independent', 'Honest']
  },
  {
    name: 'Capricorn',
    symbol: '♑',
    element: 'Earth',
    startDate: 'December 22',
    endDate: 'January 19',
    description: 'The Goat - A cardinal earth sign known for ambition, discipline, and responsibility.',
    traits: ['Ambitious', 'Disciplined', 'Responsible', 'Patient', 'Practical']
  },
  {
    name: 'Aquarius',
    symbol: '♒',
    element: 'Air',
    startDate: 'January 20',
    endDate: 'February 18',
    description: 'The Water Bearer - A fixed air sign known for innovation, independence, and humanitarianism.',
    traits: ['Independent', 'Innovative', 'Humanitarian', 'Eccentric', 'Progressive']
  },
  {
    name: 'Pisces',
    symbol: '♓',
    element: 'Water',
    startDate: 'February 19',
    endDate: 'March 20',
    description: 'The Fish - A mutable water sign known for intuition, compassion, and creativity.',
    traits: ['Intuitive', 'Compassionate', 'Artistic', 'Dreamy', 'Empathetic']
  }
];

export function calculateZodiacSign(month: number, day: number): ZodiacSign {
  const dateStr = `${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  
  // Define zodiac date ranges in MM-DD format
  const ranges = [
    { sign: 'Capricorn', start: '12-22', end: '01-19' },
    { sign: 'Aquarius', start: '01-20', end: '02-18' },
    { sign: 'Pisces', start: '02-19', end: '03-20' },
    { sign: 'Aries', start: '03-21', end: '04-19' },
    { sign: 'Taurus', start: '04-20', end: '05-20' },
    { sign: 'Gemini', start: '05-21', end: '06-20' },
    { sign: 'Cancer', start: '06-21', end: '07-22' },
    { sign: 'Leo', start: '07-23', end: '08-22' },
    { sign: 'Virgo', start: '08-23', end: '09-22' },
    { sign: 'Libra', start: '09-23', end: '10-22' },
    { sign: 'Scorpio', start: '10-23', end: '11-21' },
    { sign: 'Sagittarius', start: '11-22', end: '12-21' }
  ];

  for (const range of ranges) {
    if (range.start <= range.end) {
      // Normal case (not crossing year boundary)
      if (dateStr >= range.start && dateStr <= range.end) {
        return zodiacSigns.find(sign => sign.name === range.sign)!;
      }
    } else {
      // Capricorn case (crosses year boundary)
      if (dateStr >= range.start || dateStr <= range.end) {
        return zodiacSigns.find(sign => sign.name === range.sign)!;
      }
    }
  }
  
  // Default fallback
  return zodiacSigns[0];
}

export function getZodiacSymbol(signName: string): string {
  const sign = zodiacSigns.find(s => s.name === signName);
  return sign ? sign.symbol : '♈';
}

export function getElementColor(element: string): string {
  switch (element) {
    case 'Fire': return 'text-red-400';
    case 'Earth': return 'text-green-400';
    case 'Air': return 'text-blue-400';
    case 'Water': return 'text-cyan-400';
    default: return 'text-gray-400';
  }
}
