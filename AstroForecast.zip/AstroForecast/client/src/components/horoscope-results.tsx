import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sun, Heart, Briefcase, Leaf, Gem, CalendarDays, Share2, RotateCcw, Star } from "lucide-react";
import type { HoroscopeReading } from "@/lib/horoscope";
import type { ZodiacSign } from "@/lib/zodiac";
import { generateWeeklyStars } from "@/lib/horoscope";
import { getElementColor } from "@/lib/zodiac";

interface HoroscopeResultsProps {
  zodiacSign: ZodiacSign;
  horoscope: HoroscopeReading;
  onNewReading: () => void;
}

export function HoroscopeResults({ zodiacSign, horoscope, onNewReading }: HoroscopeResultsProps) {
  const weeklyStars = generateWeeklyStars();

  const renderStars = (count: number) => {
    const stars = [];
    for (let i = 0; i < 3; i++) {
      stars.push(
        <Star
          key={i}
          className={`w-3 h-3 ${i < count ? 'text-yellow-400' : 'text-gray-500'}`}
          fill="currentColor"
        />
      );
    }
    return stars;
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `My ${zodiacSign.name} Horoscope`,
        text: `Check out my daily horoscope reading for ${zodiacSign.name}!`,
        url: window.location.href,
      });
    } else {
      // Fallback to copying to clipboard
      navigator.clipboard.writeText(
        `My ${zodiacSign.name} horoscope for today: ${horoscope.daily}`
      );
    }
  };

  return (
    <div className="space-y-8">
      {/* Zodiac Sign Card */}
      <Card className="glass-card">
        <CardContent className="p-8">
          <div className="flex items-center justify-center mb-6">
            <div className="w-20 h-20 gradient-mystic rounded-full flex items-center justify-center mr-6 animate-float">
              <span className="text-white text-4xl">{zodiacSign.symbol}</span>
            </div>
            <div className="text-center">
              <h3 className="text-3xl font-bold text-purple-300 mb-2">{zodiacSign.name}</h3>
              <p className="text-gray-300 mb-1">{zodiacSign.startDate} - {zodiacSign.endDate}</p>
              <p className={`text-sm font-medium ${getElementColor(zodiacSign.element)}`}>
                {zodiacSign.element} Sign
              </p>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-lg text-gray-200 mb-4">{zodiacSign.description}</p>
            <div className="flex flex-wrap justify-center gap-2">
              {zodiacSign.traits.map((trait, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-white/10 rounded-full text-sm text-gray-300 border border-white/20"
                >
                  {trait}
                </span>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Today's Horoscope */}
      <Card className="glass-card">
        <CardContent className="p-8">
          <div className="flex items-center mb-6">
            <div className="w-12 h-12 gradient-cosmic rounded-full flex items-center justify-center mr-4">
              <Sun className="text-white text-xl" />
            </div>
            <div>
              <h3 className="text-2xl font-semibold text-white">Today's Horoscope</h3>
              <p className="text-gray-400 text-sm">{horoscope.date}</p>
            </div>
          </div>
          
          <div className="prose prose-invert max-w-none">
            <p className="text-lg leading-relaxed text-gray-200 mb-6">
              {horoscope.daily}
            </p>
            
            {/* Horoscope Categories */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <h4 className="font-semibold text-purple-300 mb-2 flex items-center">
                  <Heart className="w-4 h-4 mr-2" />
                  Love & Relationships
                </h4>
                <p className="text-sm text-gray-300">{horoscope.love}</p>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <h4 className="font-semibold text-blue-300 mb-2 flex items-center">
                  <Briefcase className="w-4 h-4 mr-2" />
                  Career & Finance
                </h4>
                <p className="text-sm text-gray-300">{horoscope.career}</p>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <h4 className="font-semibold text-green-400 mb-2 flex items-center">
                  <Leaf className="w-4 h-4 mr-2" />
                  Health & Wellness
                </h4>
                <p className="text-sm text-gray-300">{horoscope.health}</p>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <h4 className="font-semibold text-purple-400 mb-2 flex items-center">
                  <Gem className="w-4 h-4 mr-2" />
                  Lucky Elements
                </h4>
                <div className="text-sm text-gray-300 space-y-1">
                  <p><span className="text-purple-300">Number:</span> <span className="font-medium">{horoscope.luckyNumber}</span></p>
                  <p><span className="text-purple-300">Color:</span> <span className="font-medium">{horoscope.luckyColor}</span></p>
                  <p><span className="text-purple-300">Stone:</span> <span className="font-medium">{horoscope.luckyStone}</span></p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weekly Overview */}
      <Card className="glass-card">
        <CardContent className="p-8">
          <div className="flex items-center mb-6">
            <div className="w-12 h-12 gradient-cosmic rounded-full flex items-center justify-center mr-4">
              <CalendarDays className="text-white text-xl" />
            </div>
            <h3 className="text-2xl font-semibold text-white">This Week's Cosmic Overview</h3>
          </div>
          
          <p className="text-gray-300 mb-6">{horoscope.weeklyOverview}</p>
          
          <div className="grid grid-cols-2 md:grid-cols-7 gap-4">
            {weeklyStars.map((day, index) => (
              <div key={index} className="text-center p-3 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-colors">
                <div className="text-xs text-gray-400 mb-1">{day.day}</div>
                <div className="text-sm font-semibold mb-2 text-white">{day.date}</div>
                <div className="flex justify-center space-x-1">
                  {renderStars(day.stars)}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Footer Actions */}
      <div className="text-center space-y-4">
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Button
            onClick={handleShare}
            variant="outline"
            className="px-6 py-3 bg-white/10 hover:bg-white/20 border-white/20 text-white rounded-full transition-all duration-300"
          >
            <Share2 className="w-4 h-4 mr-2" />
            Share Reading
          </Button>
          <Button
            onClick={onNewReading}
            variant="outline"
            className="px-6 py-3 bg-white/10 hover:bg-white/20 border-white/20 text-white rounded-full transition-all duration-300"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            New Reading
          </Button>
        </div>
      </div>
    </div>
  );
}
