import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, CalendarDays, Clock, Star } from "lucide-react";
import { zodiacSignSchema, type ZodiacSignInput } from "@shared/schema";

interface BirthDateFormProps {
  onSubmit: (data: ZodiacSignInput) => void;
  isLoading?: boolean;
}

export function BirthDateForm({ onSubmit, isLoading }: BirthDateFormProps) {
  const [formData, setFormData] = useState<Partial<ZodiacSignInput>>({});
  const [errors, setErrors] = useState<Partial<Record<keyof ZodiacSignInput, string>>>({});

  const months = [
    { value: 1, label: "January" },
    { value: 2, label: "February" },
    { value: 3, label: "March" },
    { value: 4, label: "April" },
    { value: 5, label: "May" },
    { value: 6, label: "June" },
    { value: 7, label: "July" },
    { value: 8, label: "August" },
    { value: 9, label: "September" },
    { value: 10, label: "October" },
    { value: 11, label: "November" },
    { value: 12, label: "December" }
  ];

  const days = Array.from({ length: 31 }, (_, i) => i + 1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const result = zodiacSignSchema.safeParse(formData);
    
    if (!result.success) {
      const fieldErrors: Partial<Record<keyof ZodiacSignInput, string>> = {};
      result.error.errors.forEach((error) => {
        const field = error.path[0] as keyof ZodiacSignInput;
        fieldErrors[field] = error.message;
      });
      setErrors(fieldErrors);
      return;
    }

    setErrors({});
    onSubmit(result.data);
  };

  const updateField = (field: keyof ZodiacSignInput, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error for this field
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <Card className="glass-card animate-glow">
      <CardContent className="p-8">
        <div className="flex items-center justify-center mb-6">
          <div className="w-12 h-12 gradient-cosmic rounded-full flex items-center justify-center mr-4 animate-float">
            <Star className="text-white text-xl" />
          </div>
          <h3 className="text-2xl font-semibold text-white">Enter Your Birth Information</h3>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Day Input */}
            <div>
              <Label htmlFor="birth-day" className="block text-sm font-medium text-gray-300 mb-2">
                <CalendarDays className="inline w-4 h-4 mr-2" />
                Day
              </Label>
              <Select
                value={formData.day?.toString() || ""}
                onValueChange={(value) => updateField('day', parseInt(value))}
              >
                <SelectTrigger className="w-full bg-white/5 border-white/20 text-white backdrop-blur-sm focus:ring-2 focus:ring-purple-400">
                  <SelectValue placeholder="Select Day" />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-gray-700">
                  {days.map(day => (
                    <SelectItem key={day} value={day.toString()} className="text-white hover:bg-gray-800">
                      {day}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.day && <p className="text-red-400 text-sm mt-1">{errors.day}</p>}
            </div>

            {/* Month Input */}
            <div>
              <Label htmlFor="birth-month" className="block text-sm font-medium text-gray-300 mb-2">
                <Calendar className="inline w-4 h-4 mr-2" />
                Month
              </Label>
              <Select
                value={formData.month?.toString() || ""}
                onValueChange={(value) => updateField('month', parseInt(value))}
              >
                <SelectTrigger className="w-full bg-white/5 border-white/20 text-white backdrop-blur-sm focus:ring-2 focus:ring-purple-400">
                  <SelectValue placeholder="Select Month" />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-gray-700">
                  {months.map(month => (
                    <SelectItem key={month.value} value={month.value.toString()} className="text-white hover:bg-gray-800">
                      {month.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.month && <p className="text-red-400 text-sm mt-1">{errors.month}</p>}
            </div>

            {/* Year Input */}
            <div>
              <Label htmlFor="birth-year" className="block text-sm font-medium text-gray-300 mb-2">
                <Clock className="inline w-4 h-4 mr-2" />
                Year
              </Label>
              <Input
                type="number"
                placeholder="1990"
                min="1900"
                max="2024"
                value={formData.year || ""}
                onChange={(e) => updateField('year', parseInt(e.target.value) || 0)}
                className="w-full bg-white/5 border-white/20 text-white placeholder-gray-400 backdrop-blur-sm focus:ring-2 focus:ring-purple-400"
              />
              {errors.year && <p className="text-red-400 text-sm mt-1">{errors.year}</p>}
            </div>
          </div>

          {/* Submit Button */}
          <div className="text-center">
            <Button 
              type="submit" 
              disabled={isLoading}
              className="px-8 py-4 gradient-mystic hover:opacity-90 text-white font-semibold rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Calculating...
                </>
              ) : (
                <>
                  <Star className="w-4 h-4 mr-2" />
                  Reveal My Horoscope
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
