import { useState } from "react";
import { format } from "date-fns";
import { CalendarDays, Moon } from "lucide-react";
import { BirthDateForm } from "@/components/birth-date-form";
import { HoroscopeResults } from "@/components/horoscope-results";
import { calculateZodiacSign } from "@/lib/zodiac";
import { generateHoroscope } from "@/lib/horoscope";
import type { ZodiacSignInput } from "@shared/schema";
import type { ZodiacSign } from "@/lib/zodiac";
import type { HoroscopeReading } from "@/lib/horoscope";

export default function Home() {
  const [showHoroscope, setShowHoroscope] = useState(false);
  const [zodiacSign, setZodiacSign] = useState<ZodiacSign | null>(null);
  const [horoscope, setHoroscope] = useState<HoroscopeReading | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const currentDate = format(new Date(), "EEEE, MMMM do, yyyy");

  const handleGenerateHoroscope = async (data: ZodiacSignInput) => {
    setIsLoading(true);
    
    try {
      // Calculate zodiac sign
      const sign = calculateZodiacSign(data.month, data.day);
      
      // Generate horoscope
      const reading = generateHoroscope(sign.name);
      
      // Simulate API delay for better UX
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setZodiacSign(sign);
      setHoroscope(reading);
      setShowHoroscope(true);
    } catch (error) {
      console.error("Error generating horoscope:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewReading = () => {
    setShowHoroscope(false);
    setZodiacSign(null);
    setHoroscope(null);
  };

  return (
    <div className="min-h-screen cosmic-bg overflow-x-hidden">
      {/* Floating stars animation */}
      <div className="fixed inset-0 opacity-30 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-1 h-1 bg-white rounded-full animate-pulse-slow"></div>
        <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-yellow-400 rounded-full animate-pulse-slow" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-1/3 left-1/2 w-1 h-1 bg-blue-400 rounded-full animate-pulse-slow" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-white rounded-full animate-pulse-slow" style={{ animationDelay: '0.5s' }}></div>
        <div className="absolute bottom-1/4 left-1/3 w-1 h-1 bg-yellow-300 rounded-full animate-pulse-slow" style={{ animationDelay: '1.5s' }}></div>
      </div>

      {/* Header */}
      <header className="py-6 px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 gradient-mystic rounded-full flex items-center justify-center animate-float">
              <Moon className="text-purple-900 text-lg" />
            </div>
            <h1 className="text-2xl font-bold gradient-text">
              Celestial Horoscope
            </h1>
          </div>
          <div className="text-sm text-gray-300">
            <CalendarDays className="inline w-4 h-4 mr-2" />
            <span>{currentDate}</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-4 sm:px-6 lg:px-8 pb-12 relative z-10">
        <div className="max-w-4xl mx-auto">
          
          {!showHoroscope && (
            <>
              {/* Welcome Section */}
              <div className="text-center mb-12">
                <h2 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
                  Discover Your Cosmic Journey
                </h2>
                <p className="text-lg text-gray-300 max-w-2xl mx-auto">
                  Enter your birth details to unlock personalized daily insights from the stars and planets that guide your path.
                </p>
              </div>

              {/* Birth Date Input Form */}
              <BirthDateForm onSubmit={handleGenerateHoroscope} isLoading={isLoading} />
            </>
          )}

          {/* Horoscope Results */}
          {showHoroscope && zodiacSign && horoscope && (
            <HoroscopeResults
              zodiacSign={zodiacSign}
              horoscope={horoscope}
              onNewReading={handleNewReading}
            />
          )}
        </div>
      </main>
    </div>
  );
}
