import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { zodiacSignSchema } from "@shared/schema";
import { calculateZodiacSign } from "../client/src/lib/zodiac";
import { generateHoroscope } from "../client/src/lib/horoscope";

export async function registerRoutes(app: Express): Promise<Server> {
  // Calculate zodiac sign and generate horoscope
  app.post("/api/horoscope", async (req, res) => {
    try {
      const result = zodiacSignSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid birth date data",
          errors: result.error.errors 
        });
      }

      const { day, month, year } = result.data;
      
      // Calculate zodiac sign
      const zodiacSign = calculateZodiacSign(month, day);
      
      // Generate horoscope
      const horoscope = generateHoroscope(zodiacSign.name);
      
      // Store reading (optional)
      try {
        await storage.createHoroscopeReading({
          birthDay: day,
          birthMonth: month,
          birthYear: year,
          zodiacSign: zodiacSign.name
        });
      } catch (error) {
        // Continue even if storage fails
        console.warn("Failed to store horoscope reading:", error);
      }

      res.json({
        zodiacSign,
        horoscope
      });
    } catch (error) {
      console.error("Error generating horoscope:", error);
      res.status(500).json({ 
        message: "Failed to generate horoscope. Please try again." 
      });
    }
  });

  // Get daily horoscope for a specific zodiac sign
  app.get("/api/horoscope/:sign", async (req, res) => {
    try {
      const { sign } = req.params;
      
      // Validate zodiac sign
      const validSigns = [
        'aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo',
        'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces'
      ];
      
      if (!validSigns.includes(sign.toLowerCase())) {
        return res.status(400).json({ 
          message: "Invalid zodiac sign" 
        });
      }

      const capitalizedSign = sign.charAt(0).toUpperCase() + sign.slice(1).toLowerCase();
      const horoscope = generateHoroscope(capitalizedSign);
      
      res.json({ horoscope });
    } catch (error) {
      console.error("Error getting horoscope:", error);
      res.status(500).json({ 
        message: "Failed to get horoscope. Please try again." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
