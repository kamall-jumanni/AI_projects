import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const horoscopeReadings = pgTable("horoscope_readings", {
  id: serial("id").primaryKey(),
  birthDay: integer("birth_day").notNull(),
  birthMonth: integer("birth_month").notNull(),
  birthYear: integer("birth_year").notNull(),
  zodiacSign: text("zodiac_sign").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertHoroscopeReadingSchema = createInsertSchema(horoscopeReadings).pick({
  birthDay: true,
  birthMonth: true,
  birthYear: true,
  zodiacSign: true,
});

export const zodiacSignSchema = z.object({
  day: z.number().min(1).max(31),
  month: z.number().min(1).max(12),
  year: z.number().min(1900).max(2024),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertHoroscopeReading = z.infer<typeof insertHoroscopeReadingSchema>;
export type HoroscopeReading = typeof horoscopeReadings.$inferSelect;
export type ZodiacSignInput = z.infer<typeof zodiacSignSchema>;
