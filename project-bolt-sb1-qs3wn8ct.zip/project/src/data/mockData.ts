import { Venue } from '../types';

export const cuisineOptions = [
  'Indian', 'Italian', 'Chinese', 'Japanese', 'Thai', 'Mexican', 'Mediterranean', 
  'French', 'American', 'Middle Eastern', 'Korean', 'Fusion'
];

export const dietaryOptions = [
  'Vegetarian', 'Vegan', 'Gluten-Free', 'Halal', 'Jain', 'Low-Carb', 'Keto-Friendly'
];

export const mockVenues: Venue[] = [
  {
    id: '1',
    name: 'Moonlight Terrace',
    description: 'A romantic rooftop restaurant with stunning city views and candlelight dining.',
    location: {
      address: '42 Seaward Avenue, Juhu',
      city: 'Mumbai',
      latitude: 19.0822,
      longitude: 72.8417,
    },
    priceRange: 2500, // Mid-range
    rating: 4.7,
    reviews: [
      {
        id: 'r1',
        userName: 'Raj & Priya',
        rating: 5,
        comment: 'Perfect anniversary dinner spot. The sunset views were magical!',
        date: '2023-11-15',
        isCouple: true,
      },
      {
        id: 'r2',
        userName: 'Aditya M.',
        rating: 4,
        comment: 'Romantic atmosphere and good food, though slightly overpriced.',
        date: '2023-10-22',
        isCouple: true,
      },
    ],
    cuisineTypes: ['Italian', 'Mediterranean'],
    dietaryOptions: ['Vegetarian', 'Gluten-Free'],
    servesAlcohol: true,
    seatingOptions: ['indoor', 'outdoor'],
    atmosphere: ['romantic', 'formal', 'upscale'],
    operatingHours: {
      breakfast: { isOpen: false, hours: '' },
      lunch: { isOpen: true, hours: '12:00 PM - 3:00 PM' },
      dinner: { isOpen: true, hours: '7:00 PM - 11:30 PM' },
      'late-night': { isOpen: false, hours: '' },
    },
    dressCode: 'Smart Casual',
    hasReservations: true,
    currentlyAvailable: true,
    specialOffers: ['Complimentary glass of wine for couples on Tuesdays'],
    photos: [
      'https://images.pexels.com/photos/2313037/pexels-photo-2313037.jpeg',
      'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg',
      'https://images.pexels.com/photos/1307698/pexels-photo-1307698.jpeg'
    ],
    menuPreview: 'https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg',
    hasActivities: false,
    weatherSensitive: true,
  },
  {
    id: '2',
    name: 'Spice Garden',
    description: 'Authentic Indian cuisine in a beautiful garden setting with live music.',
    location: {
      address: '78 Marine Drive',
      city: 'Mumbai',
      latitude: 18.9548,
      longitude: 72.8224,
    },
    priceRange: 1800, // Mid-range
    rating: 4.5,
    reviews: [
      {
        id: 'r3',
        userName: 'Neha & Vikram',
        rating: 5,
        comment: 'Amazing food and atmosphere. The garden seating is so romantic!',
        date: '2023-12-05',
        isCouple: true,
      },
      {
        id: 'r4',
        userName: 'Shreya T.',
        rating: 4,
        comment: 'Great for a casual date night. Loved the live music!',
        date: '2023-11-18',
        isCouple: true,
      },
    ],
    cuisineTypes: ['Indian', 'Fusion'],
    dietaryOptions: ['Vegetarian', 'Vegan', 'Jain'],
    servesAlcohol: true,
    seatingOptions: ['indoor', 'outdoor'],
    atmosphere: ['casual', 'romantic', 'cultural'],
    operatingHours: {
      breakfast: { isOpen: false, hours: '' },
      lunch: { isOpen: true, hours: '12:30 PM - 3:30 PM' },
      dinner: { isOpen: true, hours: '7:00 PM - 11:00 PM' },
      'late-night': { isOpen: false, hours: '' },
    },
    dressCode: 'Casual',
    hasReservations: true,
    currentlyAvailable: true,
    specialOffers: ['20% off for couples on Wednesdays'],
    photos: [
      'https://images.pexels.com/photos/67468/pexels-photo-67468.jpeg',
      'https://images.pexels.com/photos/941869/pexels-photo-941869.jpeg',
      'https://images.pexels.com/photos/3434523/pexels-photo-3434523.jpeg'
    ],
    menuPreview: 'https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg',
    hasActivities: true,
    weatherSensitive: true,
  },
  {
    id: '3',
    name: 'Ocean Breeze Café',
    description: 'Beachside café perfect for casual dates with fresh seafood and breathtaking views.',
    location: {
      address: '23 Coastal Road, Bandra',
      city: 'Mumbai',
      latitude: 19.0596,
      longitude: 72.8295,
    },
    priceRange: 900, // Budget-friendly
    rating: 4.3,
    reviews: [
      {
        id: 'r5',
        userName: 'Arjun & Meera',
        rating: 4,
        comment: 'Perfect spot for a casual brunch date. Amazing sea views!',
        date: '2023-12-10',
        isCouple: true,
      },
      {
        id: 'r6',
        userName: 'Kavita P.',
        rating: 5,
        comment: 'Budget-friendly but doesn\'t feel cheap. Great for first dates.',
        date: '2023-11-25',
        isCouple: true,
      },
    ],
    cuisineTypes: ['Seafood', 'Cafe', 'Italian'],
    dietaryOptions: ['Vegetarian', 'Gluten-Free'],
    servesAlcohol: false,
    seatingOptions: ['outdoor'],
    atmosphere: ['casual', 'relaxed', 'scenic'],
    operatingHours: {
      breakfast: { isOpen: true, hours: '8:00 AM - 11:00 AM' },
      lunch: { isOpen: true, hours: '12:00 PM - 3:00 PM' },
      dinner: { isOpen: true, hours: '6:00 PM - 10:00 PM' },
      'late-night': { isOpen: false, hours: '' },
    },
    dressCode: 'Casual',
    hasReservations: false,
    currentlyAvailable: true,
    photos: [
      'https://images.pexels.com/photos/1581384/pexels-photo-1581384.jpeg',
      'https://images.pexels.com/photos/4916559/pexels-photo-4916559.jpeg',
      'https://images.pexels.com/photos/1878353/pexels-photo-1878353.jpeg'
    ],
    menuPreview: 'https://images.pexels.com/photos/4577177/pexels-photo-4577177.jpeg',
    hasActivities: false,
    weatherSensitive: true,
  },
  {
    id: '4',
    name: 'Starlight Cinema & Dining',
    description: 'A unique dining experience with private movie screenings and gourmet food.',
    location: {
      address: '56 Entertainment Avenue, Andheri',
      city: 'Mumbai',
      latitude: 19.1136,
      longitude: 72.8697,
    },
    priceRange: 4000, // Premium
    rating: 4.8,
    reviews: [
      {
        id: 'r7',
        userName: 'Karan & Anjali',
        rating: 5,
        comment: 'The private cinema experience was incredible! Worth every rupee for a special date.',
        date: '2023-12-15',
        isCouple: true,
      },
      {
        id: 'r8',
        userName: 'Rohan S.',
        rating: 4,
        comment: 'Amazing concept, great for anniversaries. A bit pricey but unique.',
        date: '2023-11-30',
        isCouple: true,
      },
    ],
    cuisineTypes: ['Gourmet', 'International', 'Fusion'],
    dietaryOptions: ['Vegetarian', 'Vegan', 'Gluten-Free'],
    servesAlcohol: true,
    seatingOptions: ['indoor'],
    atmosphere: ['luxurious', 'intimate', 'romantic', 'formal'],
    operatingHours: {
      breakfast: { isOpen: false, hours: '' },
      lunch: { isOpen: false, hours: '' },
      dinner: { isOpen: true, hours: '6:00 PM - 11:00 PM' },
      'late-night': { isOpen: true, hours: '11:00 PM - 1:00 AM' },
    },
    dressCode: 'Smart Casual',
    hasReservations: true,
    currentlyAvailable: false,
    specialOffers: ['Anniversary package with personalized movie selection'],
    photos: [
      'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg',
      'https://images.pexels.com/photos/7991438/pexels-photo-7991438.jpeg',
      'https://images.pexels.com/photos/7991169/pexels-photo-7991169.jpeg'
    ],
    menuPreview: 'https://images.pexels.com/photos/6685428/pexels-photo-6685428.jpeg',
    hasActivities: true,
    weatherSensitive: false,
  },
  {
    id: '5',
    name: 'Art & Sip Studio',
    description: 'Combine art with fine wines in this interactive painting studio perfect for creative couples.',
    location: {
      address: '112 Creative Lane, Powai',
      city: 'Mumbai',
      latitude: 19.1176,
      longitude: 72.9060,
    },
    priceRange: 2200, // Mid-range
    rating: 4.6,
    reviews: [
      {
        id: 'r9',
        userName: 'Amit & Sunita',
        rating: 5,
        comment: 'Such a fun date! We both loved painting together and the wine selection was excellent.',
        date: '2023-12-08',
        isCouple: true,
      },
      {
        id: 'r10',
        userName: 'Pooja M.',
        rating: 4,
        comment: 'Great for trying something different on date night. The instructors are very helpful.',
        date: '2023-11-20',
        isCouple: true,
      },
    ],
    cuisineTypes: ['Wine Bar', 'Appetizers'],
    dietaryOptions: ['Vegetarian'],
    servesAlcohol: true,
    seatingOptions: ['indoor'],
    atmosphere: ['creative', 'interactive', 'casual', 'fun'],
    operatingHours: {
      breakfast: { isOpen: false, hours: '' },
      lunch: { isOpen: false, hours: '' },
      dinner: { isOpen: true, hours: '5:00 PM - 10:00 PM' },
      'late-night': { isOpen: false, hours: '' },
    },
    dressCode: 'Casual',
    hasReservations: true,
    currentlyAvailable: true,
    specialOffers: ['Couples package includes two canvases and a bottle of wine'],
    photos: [
      'https://images.pexels.com/photos/5088188/pexels-photo-5088188.jpeg',
      'https://images.pexels.com/photos/6489663/pexels-photo-6489663.jpeg',
      'https://images.pexels.com/photos/4992463/pexels-photo-4992463.jpeg'
    ],
    hasActivities: true,
    weatherSensitive: false,
  },
  {
    id: '6',
    name: 'Lakeside Pavilion',
    description: 'Elegant dining in a tranquil lakeside setting with boat rides available.',
    location: {
      address: '89 Lake View Road, Powai',
      city: 'Mumbai',
      latitude: 19.1273,
      longitude: 72.9052,
    },
    priceRange: 3500, // Premium
    rating: 4.5,
    reviews: [
      {
        id: 'r11',
        userName: 'Vivek & Shilpa',
        rating: 5,
        comment: 'The boat ride after dinner was incredibly romantic. Perfect for our anniversary!',
        date: '2023-12-12',
        isCouple: true,
      },
      {
        id: 'r12',
        userName: 'Ananya R.',
        rating: 4,
        comment: 'Beautiful setting and excellent service. The sunset views are magical.',
        date: '2023-11-28',
        isCouple: true,
      },
    ],
    cuisineTypes: ['Continental', 'Indian', 'Seafood'],
    dietaryOptions: ['Vegetarian', 'Gluten-Free'],
    servesAlcohol: true,
    seatingOptions: ['indoor', 'outdoor'],
    atmosphere: ['romantic', 'scenic', 'elegant', 'formal'],
    operatingHours: {
      breakfast: { isOpen: false, hours: '' },
      lunch: { isOpen: true, hours: '12:00 PM - 3:00 PM' },
      dinner: { isOpen: true, hours: '7:00 PM - 11:00 PM' },
      'late-night': { isOpen: false, hours: '' },
    },
    dressCode: 'Formal',
    hasReservations: true,
    currentlyAvailable: true,
    specialOffers: ['Complimentary boat ride with dinner reservation for couples'],
    photos: [
      'https://images.pexels.com/photos/3201922/pexels-photo-3201922.jpeg',
      'https://images.pexels.com/photos/2403391/pexels-photo-2403391.jpeg',
      'https://images.pexels.com/photos/2788792/pexels-photo-2788792.jpeg'
    ],
    menuPreview: 'https://images.pexels.com/photos/6685428/pexels-photo-6685428.jpeg',
    hasActivities: true,
    weatherSensitive: true,
  }
];