// Types for the application

export interface UserLocation {
  latitude: number;
  longitude: number;
}

export interface Preferences {
  radius: number;
  transportation: 'walking' | 'public' | 'car' | 'bike';
  budget: 'budget-friendly' | 'mid-range' | 'premium';
  includingTransportation: boolean;
  alcoholPreference: 'with' | 'without' | 'either';
  cuisineTypes: string[];
  dietaryRestrictions: string[];
  seating: 'indoor' | 'outdoor' | 'either';
  dateType: 'casual' | 'formal' | 'any';
  focusType: 'activity' | 'dining' | 'balanced';
  timeOfDay: 'breakfast' | 'lunch' | 'dinner' | 'late-night' | 'any';
  specialOccasion: 'anniversary' | 'birthday' | 'first-date' | 'none';
}

export interface OperatingHours {
  breakfast: { isOpen: boolean; hours: string };
  lunch: { isOpen: boolean; hours: string };
  dinner: { isOpen: boolean; hours: string };
  'late-night': { isOpen: boolean; hours: string };
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
  isCouple: boolean;
}

export interface Venue {
  id: string;
  name: string;
  description: string;
  location: {
    address: string;
    city: string;
    latitude: number;
    longitude: number;
  };
  distance?: number; // Calculated based on user location
  travelTime?: number; // Calculated based on user location and transportation
  priceRange: number; // Average cost for two people
  rating: number;
  reviews: Review[];
  cuisineTypes: string[];
  dietaryOptions: string[];
  servesAlcohol: boolean;
  seatingOptions: string[];
  atmosphere: string[];
  operatingHours: OperatingHours;
  dressCode?: string;
  hasReservations: boolean;
  currentlyAvailable: boolean;
  specialOffers?: string[];
  photos: string[];
  menuPreview?: string;
  hasActivities: boolean;
  weatherSensitive: boolean;
}