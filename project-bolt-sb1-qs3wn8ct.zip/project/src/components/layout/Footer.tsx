import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, MapPin, Instagram, Facebook, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="text-2xl font-semibold">DateNight</Link>
            <p className="mt-4 text-gray-400">
              Discover perfect date spots tailored to your preferences and make every date night special.
            </p>
            <div className="flex mt-6 space-x-4">
              <SocialIcon icon={<Instagram size={20} />} />
              <SocialIcon icon={<Facebook size={20} />} />
              <SocialIcon icon={<Twitter size={20} />} />
            </div>
          </div>
          
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <FooterLink to="/">Home</FooterLink>
              <FooterLink to="/preferences">Find a Date</FooterLink>
              <FooterLink to="/favorites">Favorites</FooterLink>
            </ul>
          </div>
          
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Date Types</h3>
            <ul className="space-y-2">
              <FooterLink to="/preferences">Romantic Dinner</FooterLink>
              <FooterLink to="/preferences">Active Date</FooterLink>
              <FooterLink to="/preferences">Cultural Experience</FooterLink>
              <FooterLink to="/preferences">Casual Meetup</FooterLink>
            </ul>
          </div>
          
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Popular Cities</h3>
            <ul className="space-y-2">
              <li className="flex items-center text-gray-400 hover:text-white transition-colors">
                <MapPin size={16} className="mr-2" />
                <span>Mumbai</span>
              </li>
              <li className="flex items-center text-gray-400 hover:text-white transition-colors">
                <MapPin size={16} className="mr-2" />
                <span>Delhi</span>
              </li>
              <li className="flex items-center text-gray-400 hover:text-white transition-colors">
                <MapPin size={16} className="mr-2" />
                <span>Bangalore</span>
              </li>
              <li className="flex items-center text-gray-400 hover:text-white transition-colors">
                <MapPin size={16} className="mr-2" />
                <span>Chennai</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} DateNight. All rights reserved.
          </p>
          <div className="flex items-center mt-4 md:mt-0">
            <p className="text-gray-500 text-sm flex items-center">
              Made with <Heart size={14} className="mx-1 text-red-500" /> for couples
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

interface FooterLinkProps {
  to: string;
  children: React.ReactNode;
}

const FooterLink: React.FC<FooterLinkProps> = ({ to, children }) => {
  return (
    <li>
      <Link
        to={to}
        className="text-gray-400 hover:text-white transition-colors"
      >
        {children}
      </Link>
    </li>
  );
};

interface SocialIconProps {
  icon: React.ReactNode;
}

const SocialIcon: React.FC<SocialIconProps> = ({ icon }) => {
  return (
    <a
      href="#"
      className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-primary-600 transition-colors"
    >
      {icon}
    </a>
  );
};

export default Footer;