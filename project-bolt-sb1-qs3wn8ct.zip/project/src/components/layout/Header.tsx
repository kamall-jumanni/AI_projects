import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Heart, Menu, X } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const { favorites } = useAppContext();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link to="/" className="flex items-center">
          <span className={`text-2xl font-semibold ${isScrolled ? 'text-primary-600' : 'text-white'}`}>
            DateNight
          </span>
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <NavLink to="/" isActive={location.pathname === '/'} isScrolled={isScrolled}>
            Home
          </NavLink>
          <NavLink to="/preferences" isActive={location.pathname === '/preferences'} isScrolled={isScrolled}>
            Find a Date
          </NavLink>
          <NavLink to="/favorites" isActive={location.pathname === '/favorites'} isScrolled={isScrolled}>
            <div className="flex items-center">
              <Heart size={18} className="mr-1" />
              <span>Favorites</span>
              {favorites.length > 0 && (
                <span className="ml-1 bg-primary-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {favorites.length}
                </span>
              )}
            </div>
          </NavLink>
        </nav>
        
        {/* Mobile Navigation Button */}
        <button 
          className="md:hidden focus:outline-none"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? (
            <X size={24} className={isScrolled ? 'text-gray-800' : 'text-white'} />
          ) : (
            <Menu size={24} className={isScrolled ? 'text-gray-800' : 'text-white'} />
          )}
        </button>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg py-4 px-4 transition-all duration-300">
          <nav className="flex flex-col space-y-4">
            <MobileNavLink to="/" isActive={location.pathname === '/'} onClick={() => setIsMenuOpen(false)}>
              Home
            </MobileNavLink>
            <MobileNavLink to="/preferences" isActive={location.pathname === '/preferences'} onClick={() => setIsMenuOpen(false)}>
              Find a Date
            </MobileNavLink>
            <MobileNavLink to="/favorites" isActive={location.pathname === '/favorites'} onClick={() => setIsMenuOpen(false)}>
              <div className="flex items-center">
                <Heart size={18} className="mr-1" />
                <span>Favorites</span>
                {favorites.length > 0 && (
                  <span className="ml-1 bg-primary-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {favorites.length}
                  </span>
                )}
              </div>
            </MobileNavLink>
          </nav>
        </div>
      )}
    </header>
  );
};

interface NavLinkProps {
  to: string;
  isActive: boolean;
  isScrolled: boolean;
  children: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ to, isActive, isScrolled, children }) => {
  return (
    <Link
      to={to}
      className={`font-medium transition-colors duration-300 ${
        isActive
          ? 'text-primary-600'
          : isScrolled
          ? 'text-gray-800 hover:text-primary-600'
          : 'text-white hover:text-primary-100'
      }`}
    >
      {children}
    </Link>
  );
};

interface MobileNavLinkProps {
  to: string;
  isActive: boolean;
  onClick: () => void;
  children: React.ReactNode;
}

const MobileNavLink: React.FC<MobileNavLinkProps> = ({ to, isActive, onClick, children }) => {
  return (
    <Link
      to={to}
      className={`font-medium transition-colors duration-300 ${
        isActive ? 'text-primary-600' : 'text-gray-800 hover:text-primary-600'
      }`}
      onClick={onClick}
    >
      {children}
    </Link>
  );
};

export default Header;