import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Clock, DollarSign, Filter, Heart, Share2, X } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

const ResultsPage: React.FC = () => {
  const { filteredVenues, isFavorite, addToFavorites, removeFromFavorite } = useAppContext();
  const [showFilters, setShowFilters] = useState(false);
  const [sortOption, setSortOption] = useState('rating');

  useEffect(() => {
    // Update page title
    document.title = 'Date Spot Results - DateNight';
  }, []);

  const handleFavoriteToggle = (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isFavorite(id)) {
      removeFromFavorite(id);
    } else {
      addToFavorites(id);
    }
  };

  const handleShare = (venue: any, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // If Web Share API is available
    if (navigator.share) {
      navigator.share({
        title: `Check out ${venue.name} on DateNight`,
        text: `I found this amazing date spot: ${venue.name}`,
        url: window.location.href,
      });
    } else {
      // Fallback to copying to clipboard
      navigator.clipboard.writeText(`Check out ${venue.name} on DateNight: ${window.location.href}`);
      alert('Link copied to clipboard!');
    }
  };

  const sortedVenues = [...filteredVenues].sort((a, b) => {
    if (sortOption === 'rating') {
      return b.rating - a.rating;
    } else if (sortOption === 'price-low') {
      return a.priceRange - b.priceRange;
    } else if (sortOption === 'price-high') {
      return b.priceRange - a.priceRange;
    }
    return 0;
  });

  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Date Spot Results</h1>
          <p className="text-gray-600">
            Found {filteredVenues.length} spots matching your preferences
          </p>
        </div>
        
        {/* Filters and Sort Bar */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6 flex flex-col md:flex-row justify-between items-start md:items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center text-gray-700 hover:text-primary-600 transition-colors"
            >
              <Filter size={18} className="mr-1" />
              <span>Filters</span>
            </button>
          </div>
          
          <div className="flex items-center">
            <span className="text-gray-600 mr-2">Sort by:</span>
            <select 
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
              className="border border-gray-300 rounded-md py-1 px-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="rating">Highest Rated</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>
        
        {/* Filter Panel (Hidden by default) */}
        {showFilters && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-6 relative animate-fade-in">
            <button 
              onClick={() => setShowFilters(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
            >
              <X size={20} />
            </button>
            <h2 className="text-xl font-semibold mb-4">Filter Options</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Filter options would go here */}
              <div className="col-span-3 text-center">
                <button className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition-colors">
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Results Grid */}
        {sortedVenues.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedVenues.map(venue => (
              <Link 
                key={venue.id} 
                to={`/detail/${venue.id}`}
                className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={venue.photos[0]} 
                    alt={venue.name}
                    className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                  />
                  <div className="absolute top-0 left-0 right-0 p-4 flex justify-between">
                    <div className="bg-white text-primary-600 px-2 py-1 rounded-full text-sm font-semibold">
                      {venue.rating} ★
                    </div>
                    <div className="flex space-x-2">
                      <button 
                        onClick={(e) => handleShare(venue, e)}
                        className="bg-white p-2 rounded-full hover:bg-gray-100 transition-colors"
                        aria-label="Share venue"
                      >
                        <Share2 size={16} className="text-gray-700" />
                      </button>
                      <button 
                        onClick={(e) => handleFavoriteToggle(venue.id, e)}
                        className={`p-2 rounded-full transition-colors ${
                          isFavorite(venue.id) 
                            ? 'bg-red-50 hover:bg-red-100' 
                            : 'bg-white hover:bg-gray-100'
                        }`}
                        aria-label={isFavorite(venue.id) ? 'Remove from favorites' : 'Add to favorites'}
                      >
                        <Heart 
                          size={16} 
                          className={isFavorite(venue.id) ? 'text-red-500 fill-red-500' : 'text-gray-700'} 
                        />
                      </button>
                    </div>
                  </div>
                  {venue.currentlyAvailable && (
                    <div className="absolute bottom-4 left-4 bg-green-500 text-white px-3 py-1 rounded-full text-xs">
                      Available Now
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <div className="mb-2">
                    <h3 className="text-lg font-bold text-gray-900">{venue.name}</h3>
                    <p className="text-sm text-gray-600">{venue.cuisineTypes.join(', ')}</p>
                  </div>
                  <div className="flex items-center text-gray-600 text-sm mb-2">
                    <MapPin size={14} className="mr-1" />
                    <span>{venue.location.address}, {venue.location.city}</span>
                  </div>
                  <div className="flex items-center text-gray-600 text-sm mb-3">
                    <Clock size={14} className="mr-1" />
                    <span>
                      {venue.operatingHours.dinner.isOpen 
                        ? venue.operatingHours.dinner.hours 
                        : venue.operatingHours.lunch.isOpen 
                          ? venue.operatingHours.lunch.hours 
                          : 'Hours vary'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center text-primary-600 font-semibold">
                      <DollarSign size={16} className="mr-1" />
                      <span>₹{venue.priceRange} for two</span>
                    </div>
                    <span className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded">
                      {venue.atmosphere[0]}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">No Results Found</h2>
            <p className="text-gray-600 mb-6">
              We couldn't find any date spots matching your current preferences. Try adjusting your filters to see more options.
            </p>
            <Link
              to="/preferences"
              className="inline-block bg-primary-600 hover:bg-primary-700 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
            >
              Adjust Preferences
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResultsPage;