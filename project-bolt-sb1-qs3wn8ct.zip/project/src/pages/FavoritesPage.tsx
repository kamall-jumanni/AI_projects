import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Heart, X } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

const FavoritesPage: React.FC = () => {
  const { favorites, venues, removeFromFavorite } = useAppContext();
  const favoriteVenues = venues.filter(venue => favorites.includes(venue.id));
  
  useEffect(() => {
    // Update page title
    document.title = 'My Favorites - DateNight';
  }, []);

  const handleRemoveFavorite = (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    removeFromFavorite(id);
  };

  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-6">My Favorite Date Spots</h1>
        
        {favoriteVenues.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favoriteVenues.map(venue => (
              <Link 
                key={venue.id} 
                to={`/detail/${venue.id}`}
                className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow relative"
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={venue.photos[0]} 
                    alt={venue.name}
                    className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                  />
                  <button 
                    onClick={(e) => handleRemoveFavorite(venue.id, e)}
                    className="absolute top-3 right-3 bg-white p-2 rounded-full hover:bg-red-50 transition-colors group"
                    aria-label="Remove from favorites"
                  >
                    <Heart size={16} className="text-red-500 fill-red-500 group-hover:text-red-600" />
                  </button>
                </div>
                <div className="p-4">
                  <div className="mb-2">
                    <h3 className="text-lg font-bold text-gray-900">{venue.name}</h3>
                    <p className="text-sm text-gray-600">{venue.cuisineTypes.join(', ')}</p>
                  </div>
                  <div className="flex items-center text-gray-600 text-sm mb-2">
                    <MapPin size={14} className="mr-1" />
                    <span>{venue.location.address}, {venue.location.city}</span>
                  </div>
                  <div className="flex items-center">
                    <span className="mr-2 text-yellow-500">★</span>
                    <span className="font-semibold">{venue.rating}</span>
                    <span className="mx-2 text-gray-400">•</span>
                    <span className="text-primary-600 font-semibold">₹{venue.priceRange} for two</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="text-gray-400 mb-4">
              <Heart size={48} className="mx-auto" />
            </div>
            <h2 className="text-2xl font-bold mb-4">No Favorites Yet</h2>
            <p className="text-gray-600 mb-6">
              You haven't added any date spots to your favorites yet. Explore date spots and add them to your favorites list.
            </p>
            <Link
              to="/preferences"
              className="inline-block bg-primary-600 hover:bg-primary-700 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
            >
              Find Date Spots
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default FavoritesPage;