import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, CreditCard, Utensils, GlassWater, Calendar } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { cuisineOptions, dietaryOptions } from '../data/mockData';

const PreferencesPage: React.FC = () => {
  const navigate = useNavigate();
  const { preferences, setPreferences, applyFilters } = useAppContext();
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;

  useEffect(() => {
    // Update page title
    document.title = 'Set Your Date Preferences - DateNight';
  }, []);

  const handleNextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    } else {
      // Apply filters and navigate to results
      applyFilters();
      navigate('/results');
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };

  const updatePreference = (field: keyof typeof preferences, value: any) => {
    setPreferences(prev => ({ ...prev, [field]: value }));
  };

  const toggleArrayPreference = (field: keyof typeof preferences, value: string) => {
    setPreferences(prev => {
      const currentArray = prev[field] as string[];
      
      if (currentArray.includes(value)) {
        return {
          ...prev,
          [field]: currentArray.filter(item => item !== value),
        };
      } else {
        return {
          ...prev,
          [field]: [...currentArray, value],
        };
      }
    });
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="animate-fade-in">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <MapPin className="mr-2 text-primary-600" />
              Location Preferences
            </h2>
            <div className="space-y-6">
              <div>
                <label className="block text-gray-700 mb-2 font-medium">How far are you willing to travel?</label>
                <div className="flex items-center">
                  <input
                    type="range"
                    min="1"
                    max="25"
                    value={preferences.radius}
                    onChange={(e) => updatePreference('radius', parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-primary-600"
                  />
                  <span className="ml-4 text-primary-600 font-semibold">{preferences.radius} km</span>
                </div>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2 font-medium">Preferred transportation method</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <TransportButton 
                    type="walking" 
                    label="Walking"
                    isSelected={preferences.transportation === 'walking'}
                    onClick={() => updatePreference('transportation', 'walking')}
                  />
                  <TransportButton 
                    type="public" 
                    label="Public Transit"
                    isSelected={preferences.transportation === 'public'}
                    onClick={() => updatePreference('transportation', 'public')}
                  />
                  <TransportButton 
                    type="car" 
                    label="Car"
                    isSelected={preferences.transportation === 'car'}
                    onClick={() => updatePreference('transportation', 'car')}
                  />
                  <TransportButton 
                    type="bike" 
                    label="Bike"
                    isSelected={preferences.transportation === 'bike'}
                    onClick={() => updatePreference('transportation', 'bike')}
                  />
                </div>
              </div>
            </div>
          </div>
        );
      
      case 2:
        return (
          <div className="animate-fade-in">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <CreditCard className="mr-2 text-primary-600" />
              Budget Preferences
            </h2>
            <div className="space-y-6">
              <div>
                <label className="block text-gray-700 mb-2 font-medium">What's your budget range?</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <BudgetButton 
                    type="budget-friendly"
                    label="Budget-Friendly"
                    description="₹ 0-1000"
                    isSelected={preferences.budget === 'budget-friendly'}
                    onClick={() => updatePreference('budget', 'budget-friendly')}
                  />
                  <BudgetButton 
                    type="mid-range"
                    label="Mid-Range"
                    description="₹ 1000-3000"
                    isSelected={preferences.budget === 'mid-range'}
                    onClick={() => updatePreference('budget', 'mid-range')}
                  />
                  <BudgetButton 
                    type="premium"
                    label="Premium"
                    description="₹ 3000+"
                    isSelected={preferences.budget === 'premium'}
                    onClick={() => updatePreference('budget', 'premium')}
                  />
                </div>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="includingTransportation"
                  checked={preferences.includingTransportation}
                  onChange={(e) => updatePreference('includingTransportation', e.target.checked)}
                  className="w-4 h-4 text-primary-600 rounded focus:ring-primary-500"
                />
                <label htmlFor="includingTransportation" className="ml-2 text-gray-700">
                  Include transportation costs in budget
                </label>
              </div>
            </div>
          </div>
        );
      
      case 3:
        return (
          <div className="animate-fade-in">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <Utensils className="mr-2 text-primary-600" />
              Dining Preferences
            </h2>
            <div className="space-y-6">
              <div>
                <label className="block text-gray-700 mb-2 font-medium">Alcohol preference</label>
                <div className="grid grid-cols-3 gap-3">
                  <PreferenceButton 
                    label="With Alcohol"
                    isSelected={preferences.alcoholPreference === 'with'}
                    onClick={() => updatePreference('alcoholPreference', 'with')}
                  />
                  <PreferenceButton 
                    label="Without Alcohol"
                    isSelected={preferences.alcoholPreference === 'without'}
                    onClick={() => updatePreference('alcoholPreference', 'without')}
                  />
                  <PreferenceButton 
                    label="Either is fine"
                    isSelected={preferences.alcoholPreference === 'either'}
                    onClick={() => updatePreference('alcoholPreference', 'either')}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2 font-medium">Cuisine types (select multiple)</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                  {cuisineOptions.map(cuisine => (
                    <MultiSelectButton 
                      key={cuisine}
                      label={cuisine}
                      isSelected={preferences.cuisineTypes.includes(cuisine)}
                      onClick={() => toggleArrayPreference('cuisineTypes', cuisine)}
                    />
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2 font-medium">Dietary restrictions (select all that apply)</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                  {dietaryOptions.map(option => (
                    <MultiSelectButton 
                      key={option}
                      label={option}
                      isSelected={preferences.dietaryRestrictions.includes(option)}
                      onClick={() => toggleArrayPreference('dietaryRestrictions', option)}
                    />
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2 font-medium">Seating preference</label>
                <div className="grid grid-cols-3 gap-3">
                  <PreferenceButton 
                    label="Indoor"
                    isSelected={preferences.seating === 'indoor'}
                    onClick={() => updatePreference('seating', 'indoor')}
                  />
                  <PreferenceButton 
                    label="Outdoor"
                    isSelected={preferences.seating === 'outdoor'}
                    onClick={() => updatePreference('seating', 'outdoor')}
                  />
                  <PreferenceButton 
                    label="Either is fine"
                    isSelected={preferences.seating === 'either'}
                    onClick={() => updatePreference('seating', 'either')}
                  />
                </div>
              </div>
            </div>
          </div>
        );
      
      case 4:
        return (
          <div className="animate-fade-in">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <Calendar className="mr-2 text-primary-600" />
              Date Type Preferences
            </h2>
            <div className="space-y-6">
              <div>
                <label className="block text-gray-700 mb-2 font-medium">Date style</label>
                <div className="grid grid-cols-3 gap-3">
                  <PreferenceButton 
                    label="Casual"
                    isSelected={preferences.dateType === 'casual'}
                    onClick={() => updatePreference('dateType', 'casual')}
                  />
                  <PreferenceButton 
                    label="Formal"
                    isSelected={preferences.dateType === 'formal'}
                    onClick={() => updatePreference('dateType', 'formal')}
                  />
                  <PreferenceButton 
                    label="Either is fine"
                    isSelected={preferences.dateType === 'any'}
                    onClick={() => updatePreference('dateType', 'any')}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2 font-medium">Focus type</label>
                <div className="grid grid-cols-3 gap-3">
                  <PreferenceButton 
                    label="Activity-Based"
                    isSelected={preferences.focusType === 'activity'}
                    onClick={() => updatePreference('focusType', 'activity')}
                  />
                  <PreferenceButton 
                    label="Dining-Focused"
                    isSelected={preferences.focusType === 'dining'}
                    onClick={() => updatePreference('focusType', 'dining')}
                  />
                  <PreferenceButton 
                    label="Balanced Mix"
                    isSelected={preferences.focusType === 'balanced'}
                    onClick={() => updatePreference('focusType', 'balanced')}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2 font-medium">Time of day</label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  <PreferenceButton 
                    label="Breakfast"
                    isSelected={preferences.timeOfDay === 'breakfast'}
                    onClick={() => updatePreference('timeOfDay', 'breakfast')}
                  />
                  <PreferenceButton 
                    label="Lunch"
                    isSelected={preferences.timeOfDay === 'lunch'}
                    onClick={() => updatePreference('timeOfDay', 'lunch')}
                  />
                  <PreferenceButton 
                    label="Dinner"
                    isSelected={preferences.timeOfDay === 'dinner'}
                    onClick={() => updatePreference('timeOfDay', 'dinner')}
                  />
                  <PreferenceButton 
                    label="Late Night"
                    isSelected={preferences.timeOfDay === 'late-night'}
                    onClick={() => updatePreference('timeOfDay', 'late-night')}
                  />
                  <PreferenceButton 
                    label="Any Time"
                    isSelected={preferences.timeOfDay === 'any'}
                    onClick={() => updatePreference('timeOfDay', 'any')}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2 font-medium">Special occasion</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <PreferenceButton 
                    label="Anniversary"
                    isSelected={preferences.specialOccasion === 'anniversary'}
                    onClick={() => updatePreference('specialOccasion', 'anniversary')}
                  />
                  <PreferenceButton 
                    label="Birthday"
                    isSelected={preferences.specialOccasion === 'birthday'}
                    onClick={() => updatePreference('specialOccasion', 'birthday')}
                  />
                  <PreferenceButton 
                    label="First Date"
                    isSelected={preferences.specialOccasion === 'first-date'}
                    onClick={() => updatePreference('specialOccasion', 'first-date')}
                  />
                  <PreferenceButton 
                    label="No Special Occasion"
                    isSelected={preferences.specialOccasion === 'none'}
                    onClick={() => updatePreference('specialOccasion', 'none')}
                  />
                </div>
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-lg p-6 md:p-8">
          <h1 className="text-3xl font-bold mb-6 text-center">Find Your Perfect Date Spot</h1>
          
          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex justify-between mb-2">
              {Array.from({ length: totalSteps }).map((_, i) => (
                <div 
                  key={i}
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm
                    ${i + 1 === currentStep 
                      ? 'bg-primary-600 text-white' 
                      : i + 1 < currentStep 
                        ? 'bg-primary-100 text-primary-600' 
                        : 'bg-gray-200 text-gray-500'}`}
                >
                  {i + 1}
                </div>
              ))}
            </div>
            <div className="h-2 bg-gray-200 rounded-full">
              <div 
                className="h-full bg-primary-600 rounded-full transition-all duration-300"
                style={{ width: `${(currentStep / totalSteps) * 100}%` }}
              ></div>
            </div>
          </div>
          
          {/* Step Content */}
          {renderStepContent()}
          
          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8">
            <button
              onClick={handlePrevStep}
              disabled={currentStep === 1}
              className={`px-6 py-2 rounded-lg font-medium transition-colors
                ${currentStep === 1 
                  ? 'bg-gray-200 text-gray-400 cursor-not-allowed' 
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
            >
              Previous
            </button>
            <button
              onClick={handleNextStep}
              className="px-6 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors"
            >
              {currentStep === totalSteps ? 'Find Date Spots' : 'Next'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

interface TransportButtonProps {
  type: string;
  label: string;
  isSelected: boolean;
  onClick: () => void;
}

const TransportButton: React.FC<TransportButtonProps> = ({ type, label, isSelected, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`p-3 rounded-lg border-2 transition-all
        ${isSelected 
          ? 'border-primary-600 bg-primary-50 text-primary-600' 
          : 'border-gray-200 hover:border-gray-300 text-gray-700'}`}
    >
      {label}
    </button>
  );
};

interface BudgetButtonProps {
  type: string;
  label: string;
  description: string;
  isSelected: boolean;
  onClick: () => void;
}

const BudgetButton: React.FC<BudgetButtonProps> = ({ type, label, description, isSelected, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`p-4 rounded-lg border-2 transition-all
        ${isSelected 
          ? 'border-primary-600 bg-primary-50 text-primary-600' 
          : 'border-gray-200 hover:border-gray-300 text-gray-700'}`}
    >
      <div className="font-medium">{label}</div>
      <div className="text-sm">{description}</div>
    </button>
  );
};

interface PreferenceButtonProps {
  label: string;
  isSelected: boolean;
  onClick: () => void;
}

const PreferenceButton: React.FC<PreferenceButtonProps> = ({ label, isSelected, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`py-2 px-4 rounded-lg border transition-all text-sm
        ${isSelected 
          ? 'border-primary-600 bg-primary-50 text-primary-600' 
          : 'border-gray-200 hover:border-gray-300 text-gray-700'}`}
    >
      {label}
    </button>
  );
};

interface MultiSelectButtonProps {
  label: string;
  isSelected: boolean;
  onClick: () => void;
}

const MultiSelectButton: React.FC<MultiSelectButtonProps> = ({ label, isSelected, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`py-2 px-3 rounded-lg transition-all text-sm
        ${isSelected 
          ? 'bg-primary-600 text-white' 
          : 'bg-gray-100 hover:bg-gray-200 text-gray-700'}`}
    >
      {label}
    </button>
  );
};

export default PreferencesPage;