import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Calendar, DollarSign, Utensils, ArrowRight } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

const HomePage: React.FC = () => {
  const { venues } = useAppContext();
  
  // Find featured venues (top rated)
  const featuredVenues = venues
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 3);

  useEffect(() => {
    // Update page title
    document.title = 'DateNight - Find Perfect Date Spots';
  }, []);

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section 
        className="relative h-screen flex items-center justify-center bg-cover bg-center"
        style={{ 
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), 
          url('https://images.pexels.com/photos/1307698/pexels-photo-1307698.jpeg')` 
        }}
      >
        <div className="container mx-auto px-4 text-center text-white">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight animate-fade-in">
              Discover Your Perfect Date Night
            </h1>
            <p className="text-xl md:text-2xl mb-8 animate-fade-in-delay">
              Personalized recommendations for unforgettable moments together
            </p>
            <Link 
              to="/preferences" 
              className="inline-block bg-primary-600 hover:bg-primary-700 text-white font-semibold px-8 py-4 rounded-full text-lg transition-all transform hover:scale-105 animate-bounce-in"
            >
              Find Date Spots
            </Link>
          </div>
        </div>
        
        <div className="absolute bottom-8 left-0 right-0 flex justify-center">
          <div className="animate-bounce">
            <ArrowRight size={24} className="text-white transform rotate-90" />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">How It Works</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<MapPin size={32} className="text-primary-600" />}
              title="Set Your Location"
              description="Tell us where you are and how far you're willing to travel"
              step={1}
            />
            <FeatureCard 
              icon={<DollarSign size={32} className="text-primary-600" />}
              title="Choose Your Budget"
              description="Select your price range from budget-friendly to premium"
              step={2}
            />
            <FeatureCard 
              icon={<Utensils size={32} className="text-primary-600" />}
              title="Set Preferences"
              description="Tell us your dining and activity preferences"
              step={3}
            />
            <FeatureCard 
              icon={<Calendar size={32} className="text-primary-600" />}
              title="Plan Your Date"
              description="Get personalized recommendations and book your perfect date"
              step={4}
            />
          </div>
        </div>
      </section>

      {/* Featured Venues Section */}
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">Featured Date Spots</h2>
          <p className="text-xl text-gray-600 text-center mb-12">Discover some of our highest-rated date venues</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredVenues.map(venue => (
              <div 
                key={venue.id}
                className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform transform hover:scale-105"
              >
                <div className="h-64 overflow-hidden">
                  <img 
                    src={venue.photos[0]} 
                    alt={venue.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-xl font-bold">{venue.name}</h3>
                    <div className="flex items-center bg-primary-100 text-primary-800 px-2 py-1 rounded">
                      <span className="font-semibold">{venue.rating}</span>
                      <span className="ml-1">★</span>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mb-4">{venue.cuisineTypes.join(', ')}</p>
                  <div className="flex items-center text-gray-500 text-sm mb-4">
                    <MapPin size={16} className="mr-1" />
                    <span>{venue.location.address}, {venue.location.city}</span>
                  </div>
                  <p className="text-gray-700 mb-4 line-clamp-2">{venue.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-primary-600 font-semibold">₹{venue.priceRange} for two</span>
                    <Link
                      to={`/detail/${venue.id}`}
                      className="text-primary-600 font-semibold hover:text-primary-800 flex items-center"
                    >
                      View Details
                      <ArrowRight size={16} className="ml-1" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link
              to="/preferences"
              className="inline-block bg-primary-600 hover:bg-primary-700 text-white font-semibold px-6 py-3 rounded-full transition-all"
            >
              Explore All Date Spots
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Couples Love Us</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <TestimonialCard
              quote="DateNight helped us find the perfect anniversary dinner spot. The recommendations were spot on!"
              author="Raj & Priya"
              location="Mumbai"
            />
            <TestimonialCard
              quote="We were tired of going to the same places. This app introduced us to amazing new date spots we never knew existed."
              author="Aditya & Meera"
              location="Delhi"
            />
            <TestimonialCard
              quote="The budget filter is so helpful. We found a romantic rooftop restaurant that didn't break the bank!"
              author="Vikram & Neha"
              location="Bangalore"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Plan Your Perfect Date?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Stop wondering where to go. Find the perfect spot based on your preferences and make memories that last.
          </p>
          <Link
            to="/preferences"
            className="inline-block bg-white text-primary-700 hover:bg-gray-100 font-semibold px-8 py-4 rounded-full text-lg transition-all transform hover:scale-105"
          >
            Find Date Spots Now
          </Link>
        </div>
      </section>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  step: number;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description, step }) => {
  return (
    <div className="text-center p-6 relative">
      <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-primary-600 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">
        {step}
      </div>
      <div className="mb-4 flex justify-center">{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

interface TestimonialCardProps {
  quote: string;
  author: string;
  location: string;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ quote, author, location }) => {
  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <div className="text-primary-400 text-5xl font-serif mb-4">"</div>
      <p className="text-gray-300 mb-6">{quote}</p>
      <div className="flex items-center">
        <div className="w-10 h-10 bg-primary-500 rounded-full flex items-center justify-center text-white font-semibold mr-3">
          {author.split(' ')[0][0]}
        </div>
        <div>
          <p className="font-semibold">{author}</p>
          <p className="text-gray-400 text-sm">{location}</p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;