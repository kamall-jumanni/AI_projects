import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  MapPin, Clock, DollarSign, Calendar, Phone, Heart, Share2, 
  CheckCircle, AlertTriangle, Umbrella, ChevronLeft, ArrowRight 
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';

const DetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getVenueById, isFavorite, addToFavorites, removeFromFavorite } = useAppContext();
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [isReservationModalOpen, setIsReservationModalOpen] = useState(false);
  
  const venue = getVenueById(id || '');
  
  useEffect(() => {
    // Update page title
    if (venue) {
      document.title = `${venue.name} - DateNight`;
    } else {
      // If venue not found, redirect to results
      navigate('/results');
    }
  }, [venue, navigate]);

  if (!venue) {
    return null;
  }

  const handleFavoriteToggle = () => {
    if (isFavorite(venue.id)) {
      removeFromFavorite(venue.id);
    } else {
      addToFavorites(venue.id);
    }
  };

  const handleShare = () => {
    // If Web Share API is available
    if (navigator.share) {
      navigator.share({
        title: `Check out ${venue.name} on DateNight`,
        text: `I found this amazing date spot: ${venue.name}`,
        url: window.location.href,
      });
    } else {
      // Fallback to copying to clipboard
      navigator.clipboard.writeText(`Check out ${venue.name} on DateNight: ${window.location.href}`);
      alert('Link copied to clipboard!');
    }
  };

  const renderWeatherAlert = () => {
    if (venue.weatherSensitive && venue.seatingOptions.includes('outdoor')) {
      return (
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6 flex items-start">
          <Umbrella size={20} className="text-blue-500 mr-2 mt-0.5" />
          <div>
            <h4 className="font-semibold text-blue-700">Weather Alert</h4>
            <p className="text-blue-600 text-sm">
              This venue has outdoor seating and may be affected by weather conditions. 
              Check the forecast before you go.
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-600 hover:text-primary-600 mb-4 transition-colors"
        >
          <ChevronLeft size={20} className="mr-1" />
          <span>Back to results</span>
        </button>
        
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          {/* Image Gallery */}
          <div className="relative h-80 sm:h-96 md:h-[30rem] overflow-hidden">
            <img
              src={venue.photos[activeImageIndex]}
              alt={venue.name}
              className="w-full h-full object-cover"
            />
            
            {/* Image Navigation Arrows */}
            {venue.photos.length > 1 && (
              <>
                <button
                  onClick={() => setActiveImageIndex((prev) => (prev === 0 ? venue.photos.length - 1 : prev - 1))}
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-40 hover:bg-opacity-60 rounded-full p-2 text-white transition-all"
                  aria-label="Previous image"
                >
                  <ChevronLeft size={24} />
                </button>
                <button
                  onClick={() => setActiveImageIndex((prev) => (prev === venue.photos.length - 1 ? 0 : prev + 1))}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-40 hover:bg-opacity-60 rounded-full p-2 text-white transition-all"
                  aria-label="Next image"
                >
                  <ArrowRight size={24} />
                </button>
              </>
            )}
            
            {/* Image Indicators */}
            {venue.photos.length > 1 && (
              <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
                {venue.photos.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveImageIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === activeImageIndex ? 'bg-white w-4' : 'bg-white bg-opacity-50'
                    }`}
                    aria-label={`View image ${index + 1}`}
                  />
                ))}
              </div>
            )}
            
            {/* Action Buttons */}
            <div className="absolute top-4 right-4 flex space-x-3">
              <button
                onClick={handleShare}
                className="bg-white p-3 rounded-full hover:bg-gray-100 transition-colors flex items-center justify-center"
                aria-label="Share venue"
              >
                <Share2 size={18} className="text-gray-700" />
              </button>
              <button
                onClick={handleFavoriteToggle}
                className={`p-3 rounded-full transition-colors flex items-center justify-center ${
                  isFavorite(venue.id)
                    ? 'bg-red-50 hover:bg-red-100'
                    : 'bg-white hover:bg-gray-100'
                }`}
                aria-label={isFavorite(venue.id) ? 'Remove from favorites' : 'Add to favorites'}
              >
                <Heart
                  size={18}
                  className={isFavorite(venue.id) ? 'text-red-500 fill-red-500' : 'text-gray-700'}
                />
              </button>
            </div>
          </div>
          
          <div className="p-6 md:p-8">
            {/* Venue Title and Status */}
            <div className="flex justify-between items-start mb-6">
              <div>
                <h1 className="text-3xl font-bold mb-1">{venue.name}</h1>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="flex items-center mr-3">
                    <span className="font-semibold text-primary-600 mr-1">{venue.rating}</span>
                    <span className="text-yellow-500">★</span>
                  </span>
                  <span className="mr-3">{venue.cuisineTypes.join(', ')}</span>
                  <span>{venue.atmosphere.join(', ')}</span>
                </div>
              </div>
              <div>
                {venue.currentlyAvailable ? (
                  <span className="inline-flex items-center bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                    <CheckCircle size={14} className="mr-1" />
                    Available Now
                  </span>
                ) : (
                  <span className="inline-flex items-center bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm">
                    <AlertTriangle size={14} className="mr-1" />
                    Limited Availability
                  </span>
                )}
              </div>
            </div>
            
            {/* Key Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <div className="flex items-start mb-4">
                  <MapPin size={18} className="text-primary-600 mr-2 mt-0.5" />
                  <div>
                    <h3 className="font-semibold">Location</h3>
                    <p className="text-gray-600">{venue.location.address}, {venue.location.city}</p>
                    <p className="text-sm text-gray-500 mt-1">3.2 km away • 15 min by car</p>
                  </div>
                </div>
                
                <div className="flex items-start mb-4">
                  <Clock size={18} className="text-primary-600 mr-2 mt-0.5" />
                  <div>
                    <h3 className="font-semibold">Hours</h3>
                    {venue.operatingHours.lunch.isOpen && (
                      <p className="text-gray-600">Lunch: {venue.operatingHours.lunch.hours}</p>
                    )}
                    {venue.operatingHours.dinner.isOpen && (
                      <p className="text-gray-600">Dinner: {venue.operatingHours.dinner.hours}</p>
                    )}
                  </div>
                </div>
                
                <div className="flex items-start">
                  <DollarSign size={18} className="text-primary-600 mr-2 mt-0.5" />
                  <div>
                    <h3 className="font-semibold">Price Range</h3>
                    <p className="text-gray-600">₹{venue.priceRange} for two people (approx.)</p>
                  </div>
                </div>
              </div>
              
              <div>
                {venue.dressCode && (
                  <div className="flex items-start mb-4">
                    <Calendar size={18} className="text-primary-600 mr-2 mt-0.5" />
                    <div>
                      <h3 className="font-semibold">Dress Code</h3>
                      <p className="text-gray-600">{venue.dressCode}</p>
                    </div>
                  </div>
                )}
                
                <div className="flex items-start mb-4">
                  <Phone size={18} className="text-primary-600 mr-2 mt-0.5" />
                  <div>
                    <h3 className="font-semibold">Reservations</h3>
                    <p className="text-gray-600">
                      {venue.hasReservations 
                        ? 'Reservations accepted and recommended' 
                        : 'No reservations, walk-ins only'}
                    </p>
                  </div>
                </div>
                
                {venue.specialOffers && venue.specialOffers.length > 0 && (
                  <div className="bg-primary-50 border border-primary-200 rounded-lg p-3">
                    <h3 className="font-semibold text-primary-800 mb-1">Special Offers</h3>
                    <ul className="text-primary-700 text-sm">
                      {venue.specialOffers.map((offer, index) => (
                        <li key={index} className="flex items-start mb-1 last:mb-0">
                          <span className="mr-1">•</span>
                          <span>{offer}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
            
            {/* Weather Alert */}
            {renderWeatherAlert()}
            
            {/* Description */}
            <div className="mb-8">
              <h2 className="text-xl font-bold mb-3">About {venue.name}</h2>
              <div className={showFullDescription ? '' : 'line-clamp-3'}>
                <p className="text-gray-700">{venue.description}</p>
                <p className="mt-3 text-gray-700">
                  This venue is perfect for {venue.atmosphere.join(', ')} dates. 
                  {venue.servesAlcohol && ' They offer a selection of alcoholic beverages.'} 
                  {venue.hasActivities && ' There are activities available to enhance your date experience.'}
                </p>
              </div>
              {venue.description.length > 150 && (
                <button
                  onClick={() => setShowFullDescription(!showFullDescription)}
                  className="text-primary-600 hover:text-primary-800 font-medium mt-2 transition-colors"
                >
                  {showFullDescription ? 'Show Less' : 'Read More'}
                </button>
              )}
            </div>
            
            {/* Amenities/Features */}
            <div className="mb-8">
              <h2 className="text-xl font-bold mb-3">Features</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-y-3">
                <Feature label="Seating Options" value={venue.seatingOptions.map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(', ')} />
                <Feature label="Serves Alcohol" value={venue.servesAlcohol ? 'Yes' : 'No'} />
                <Feature label="Activities" value={venue.hasActivities ? 'Available' : 'None'} />
                <Feature label="Dietary Options" value={venue.dietaryOptions.join(', ')} />
                {venue.dressCode && <Feature label="Dress Code\" value={venue.dressCode} />}
              </div>
            </div>
            
            {/* Reviews Section */}
            <div className="mb-8">
              <h2 className="text-xl font-bold mb-3">Couple Reviews</h2>
              <div className="space-y-4">
                {venue.reviews.map(review => (
                  <div key={review.id} className="border-b border-gray-200 pb-4 last:border-b-0 last:pb-0">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center font-semibold mr-3">
                          {review.userName.split(' ')[0][0]}
                        </div>
                        <div>
                          <h3 className="font-semibold">{review.userName}</h3>
                          <p className="text-gray-500 text-sm">{review.date}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <span className="font-semibold mr-1">{review.rating}</span>
                        <span className="text-yellow-500">★</span>
                      </div>
                    </div>
                    <p className="text-gray-700">{review.comment}</p>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Call to Action */}
            <div className="border-t border-gray-200 pt-6 flex flex-col sm:flex-row justify-between items-center">
              <div className="mb-4 sm:mb-0">
                <h3 className="font-semibold text-lg mb-1">Ready for an unforgettable date?</h3>
                <p className="text-gray-600">Book now to secure your spot at {venue.name}</p>
              </div>
              <button
                onClick={() => setIsReservationModalOpen(true)}
                className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
                disabled={!venue.hasReservations}
              >
                {venue.hasReservations ? 'Make a Reservation' : 'No Reservations Available'}
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Reservation Modal */}
      {isReservationModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 animate-fade-in">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Reserve a Table</h2>
              <button 
                onClick={() => setIsReservationModalOpen(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={20} />
              </button>
            </div>
            
            <form className="space-y-4">
              <div>
                <label className="block text-gray-700 mb-1 font-medium">Date</label>
                <input 
                  type="date" 
                  className="w-full border border-gray-300 rounded-lg p-2 focus:ring-primary-500 focus:border-primary-500"
                />
              </div>
              
              <div>
                <label className="block text-gray-700 mb-1 font-medium">Time</label>
                <select className="w-full border border-gray-300 rounded-lg p-2 focus:ring-primary-500 focus:border-primary-500">
                  <option>7:00 PM</option>
                  <option>7:30 PM</option>
                  <option>8:00 PM</option>
                  <option>8:30 PM</option>
                  <option>9:00 PM</option>
                </select>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-1 font-medium">Number of People</label>
                <select className="w-full border border-gray-300 rounded-lg p-2 focus:ring-primary-500 focus:border-primary-500">
                  <option>2 people</option>
                  <option>3 people</option>
                  <option>4 people</option>
                  <option>5+ people</option>
                </select>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-1 font-medium">Special Requests</label>
                <textarea 
                  className="w-full border border-gray-300 rounded-lg p-2 focus:ring-primary-500 focus:border-primary-500"
                  rows={3}
                  placeholder="Any special requests or notes for the restaurant..."
                />
              </div>
              
              <button
                type="button"
                className="w-full bg-primary-600 hover:bg-primary-700 text-white py-3 rounded-lg font-semibold transition-colors"
              >
                Confirm Reservation
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

interface FeatureProps {
  label: string;
  value: string;
}

const Feature: React.FC<FeatureProps> = ({ label, value }) => {
  return (
    <div>
      <span className="text-gray-600 mr-1">{label}:</span>
      <span className="font-medium">{value}</span>
    </div>
  );
};

export default DetailPage;