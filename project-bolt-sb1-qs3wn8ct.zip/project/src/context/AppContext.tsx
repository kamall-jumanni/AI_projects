import React, { createContext, useContext, useState, useEffect } from 'react';
import { mockVenues } from '../data/mockData';
import { Venue, Preferences, UserLocation } from '../types';

interface AppContextType {
  preferences: Preferences;
  setPreferences: React.Dispatch<React.SetStateAction<Preferences>>;
  venues: Venue[];
  filteredVenues: Venue[];
  userLocation: UserLocation | null;
  setUserLocation: React.Dispatch<React.SetStateAction<UserLocation | null>>;
  favorites: string[];
  addToFavorites: (id: string) => void;
  removeFromFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
  getVenueById: (id: string) => Venue | undefined;
  applyFilters: () => void;
}

const defaultPreferences: Preferences = {
  radius: 5,
  transportation: 'car',
  budget: 'mid-range',
  includingTransportation: false,
  alcoholPreference: 'either',
  cuisineTypes: [],
  dietaryRestrictions: [],
  seating: 'either',
  dateType: 'casual',
  focusType: 'balanced',
  timeOfDay: 'dinner',
  specialOccasion: 'none',
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [preferences, setPreferences] = useState<Preferences>(defaultPreferences);
  const [venues, setVenues] = useState<Venue[]>(mockVenues);
  const [filteredVenues, setFilteredVenues] = useState<Venue[]>(mockVenues);
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);

  useEffect(() => {
    // Load favorites from localStorage
    const savedFavorites = localStorage.getItem('favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
    
    // Simulate getting user location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        () => {
          // Default location (Mumbai)
          setUserLocation({
            latitude: 19.076,
            longitude: 72.8777,
          });
        }
      );
    }
  }, []);

  useEffect(() => {
    // Save favorites to localStorage whenever it changes
    localStorage.setItem('favorites', JSON.stringify(favorites));
  }, [favorites]);

  const addToFavorites = (id: string) => {
    setFavorites((prev) => [...prev, id]);
  };

  const removeFromFavorite = (id: string) => {
    setFavorites((prev) => prev.filter((favId) => favId !== id));
  };

  const isFavorite = (id: string) => {
    return favorites.includes(id);
  };

  const getVenueById = (id: string) => {
    return venues.find((venue) => venue.id === id);
  };

  const applyFilters = () => {
    let results = [...venues];
    
    // Filter by budget
    if (preferences.budget === 'budget-friendly') {
      results = results.filter(venue => venue.priceRange <= 1000);
    } else if (preferences.budget === 'mid-range') {
      results = results.filter(venue => venue.priceRange > 1000 && venue.priceRange <= 3000);
    } else if (preferences.budget === 'premium') {
      results = results.filter(venue => venue.priceRange > 3000);
    }
    
    // Filter by cuisine if any selected
    if (preferences.cuisineTypes.length > 0) {
      results = results.filter(venue => 
        preferences.cuisineTypes.some(cuisine => venue.cuisineTypes.includes(cuisine))
      );
    }
    
    // Filter by dietary restrictions
    if (preferences.dietaryRestrictions.length > 0) {
      results = results.filter(venue => 
        preferences.dietaryRestrictions.every(restriction => 
          venue.dietaryOptions.includes(restriction)
        )
      );
    }
    
    // Filter by alcohol preference
    if (preferences.alcoholPreference !== 'either') {
      results = results.filter(venue => 
        venue.servesAlcohol === (preferences.alcoholPreference === 'with')
      );
    }
    
    // Filter by seating preference
    if (preferences.seating !== 'either') {
      results = results.filter(venue => 
        venue.seatingOptions.includes(preferences.seating)
      );
    }
    
    // Filter by date type
    if (preferences.dateType !== 'any') {
      results = results.filter(venue => 
        venue.atmosphere.includes(preferences.dateType)
      );
    }
    
    // Filter by focus type
    if (preferences.focusType === 'activity') {
      results = results.filter(venue => venue.hasActivities);
    } else if (preferences.focusType === 'dining') {
      results = results.filter(venue => !venue.hasActivities);
    }
    
    // Filter by time of day
    if (preferences.timeOfDay !== 'any') {
      results = results.filter(venue => 
        venue.operatingHours[preferences.timeOfDay].isOpen
      );
    }
    
    // Sort by match score (would be calculated based on multiple factors)
    results.sort((a, b) => b.rating - a.rating);
    
    setFilteredVenues(results);
  };

  return (
    <AppContext.Provider
      value={{
        preferences,
        setPreferences,
        venues,
        filteredVenues,
        userLocation,
        setUserLocation,
        favorites,
        addToFavorites,
        removeFromFavorite,
        isFavorite,
        getVenueById,
        applyFilters,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};