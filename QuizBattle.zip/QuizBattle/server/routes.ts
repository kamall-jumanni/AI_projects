import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGameSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create new game
  app.post("/api/games", async (req, res) => {
    try {
      const gameData = insertGameSchema.parse(req.body);
      const game = await storage.createGame(gameData);
      res.json(game);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid game data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create game" });
      }
    }
  });

  // Get game by ID
  app.get("/api/games/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const game = await storage.getGame(id);
      
      if (!game) {
        res.status(404).json({ message: "Game not found" });
        return;
      }
      
      res.json(game);
    } catch (error) {
      res.status(500).json({ message: "Failed to get game" });
    }
  });

  // Update game score and progress
  app.patch("/api/games/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { team1Score, team2Score, currentQuestion, currentTeam } = req.body;
      
      const game = await storage.updateGameScore(id, team1Score, team2Score, currentQuestion, currentTeam);
      
      if (!game) {
        res.status(404).json({ message: "Game not found" });
        return;
      }
      
      res.json(game);
    } catch (error) {
      res.status(500).json({ message: "Failed to update game" });
    }
  });

  // Complete game
  app.patch("/api/games/:id/complete", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const game = await storage.completeGame(id);
      
      if (!game) {
        res.status(404).json({ message: "Game not found" });
        return;
      }
      
      res.json(game);
    } catch (error) {
      res.status(500).json({ message: "Failed to complete game" });
    }
  });

  // Get random questions for a game
  app.get("/api/questions/random/:count", async (req, res) => {
    try {
      const count = parseInt(req.params.count);
      const questions = await storage.getRandomQuestions(count);
      res.json(questions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get questions" });
    }
  });

  // Get all questions
  app.get("/api/questions", async (req, res) => {
    try {
      const questions = await storage.getAllQuestions();
      res.json(questions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get questions" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
