import { users, games, questions, type User, type InsertUser, type Game, type InsertGame, type Question, type InsertQuestion } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createGame(game: InsertGame): Promise<Game>;
  getGame(id: number): Promise<Game | undefined>;
  updateGameScore(id: number, team1Score: number, team2Score: number, currentQuestion: number, currentTeam: number): Promise<Game | undefined>;
  completeGame(id: number): Promise<Game | undefined>;
  
  getRandomQuestions(limit: number): Promise<Question[]>;
  getAllQuestions(): Promise<Question[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private games: Map<number, Game>;
  private questions: Map<number, Question>;
  private currentUserId: number;
  private currentGameId: number;
  private currentQuestionId: number;

  constructor() {
    this.users = new Map();
    this.games = new Map();
    this.questions = new Map();
    this.currentUserId = 1;
    this.currentGameId = 1;
    this.currentQuestionId = 1;
    
    // Initialize with sample questions
    this.initializeQuestions();
  }

  private initializeQuestions() {
    const sampleQuestions: InsertQuestion[] = [
      {
        category: "Science",
        question: "What is the chemical symbol for gold on the periodic table?",
        optionA: "Au",
        optionB: "Ag",
        optionC: "Go",
        optionD: "Gd",
        correctAnswer: "A"
      },
      {
        category: "History",
        question: "In which year did World War II end?",
        optionA: "1944",
        optionB: "1945",
        optionC: "1946",
        optionD: "1947",
        correctAnswer: "B"
      },
      {
        category: "Geography",
        question: "What is the capital city of Australia?",
        optionA: "Sydney",
        optionB: "Melbourne",
        optionC: "Canberra",
        optionD: "Perth",
        correctAnswer: "C"
      },
      {
        category: "Literature",
        question: "Who wrote the novel '1984'?",
        optionA: "Aldous Huxley",
        optionB: "George Orwell",
        optionC: "Ray Bradbury",
        optionD: "H.G. Wells",
        correctAnswer: "B"
      },
      {
        category: "Math",
        question: "What is the value of π (pi) to two decimal places?",
        optionA: "3.14",
        optionB: "3.16",
        optionC: "3.12",
        optionD: "3.18",
        correctAnswer: "A"
      },
      {
        category: "Science",
        question: "Which planet is known as the 'Red Planet'?",
        optionA: "Venus",
        optionB: "Jupiter",
        optionC: "Mars",
        optionD: "Saturn",
        correctAnswer: "C"
      },
      {
        category: "Sports",
        question: "How many players are on a basketball team on the court at one time?",
        optionA: "4",
        optionB: "5",
        optionC: "6",
        optionD: "7",
        correctAnswer: "B"
      },
      {
        category: "Technology",
        question: "What does 'HTTP' stand for?",
        optionA: "HyperText Transfer Protocol",
        optionB: "High Tech Transfer Protocol",
        optionC: "HyperText Transport Protocol",
        optionD: "High Transfer Text Protocol",
        correctAnswer: "A"
      },
      {
        category: "Art",
        question: "Who painted the famous artwork 'The Starry Night'?",
        optionA: "Pablo Picasso",
        optionB: "Leonardo da Vinci",
        optionC: "Vincent van Gogh",
        optionD: "Claude Monet",
        correctAnswer: "C"
      },
      {
        category: "Music",
        question: "How many strings does a standard guitar have?",
        optionA: "4",
        optionB: "5",
        optionC: "6",
        optionD: "7",
        correctAnswer: "C"
      },
      {
        category: "Science",
        question: "What is the largest organ in the human body?",
        optionA: "Heart",
        optionB: "Brain",
        optionC: "Liver",
        optionD: "Skin",
        correctAnswer: "D"
      },
      {
        category: "Geography",
        question: "Which continent is home to the Amazon rainforest?",
        optionA: "Africa",
        optionB: "Asia",
        optionC: "South America",
        optionD: "North America",
        correctAnswer: "C"
      },
      {
        category: "History",
        question: "Who was the first person to walk on the moon?",
        optionA: "Buzz Aldrin",
        optionB: "Neil Armstrong",
        optionC: "John Glenn",
        optionD: "Alan Shepard",
        correctAnswer: "B"
      },
      {
        category: "Math",
        question: "What is 15% of 200?",
        optionA: "25",
        optionB: "30",
        optionC: "35",
        optionD: "40",
        correctAnswer: "B"
      },
      {
        category: "Literature",
        question: "In Shakespeare's play, who is the Prince of Denmark?",
        optionA: "Macbeth",
        optionB: "Othello",
        optionC: "Hamlet",
        optionD: "Romeo",
        correctAnswer: "C"
      }
    ];

    sampleQuestions.forEach(q => {
      const question: Question = { ...q, id: this.currentQuestionId++ };
      this.questions.set(question.id, question);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = this.currentGameId++;
    const game: Game = {
      ...insertGame,
      id,
      team1Score: 0,
      team2Score: 0,
      currentQuestion: 1,
      currentTeam: 1,
      isCompleted: false,
    };
    this.games.set(id, game);
    return game;
  }

  async getGame(id: number): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async updateGameScore(id: number, team1Score: number, team2Score: number, currentQuestion: number, currentTeam: number): Promise<Game | undefined> {
    const game = this.games.get(id);
    if (!game) return undefined;

    const updatedGame: Game = {
      ...game,
      team1Score,
      team2Score,
      currentQuestion,
      currentTeam,
    };
    this.games.set(id, updatedGame);
    return updatedGame;
  }

  async completeGame(id: number): Promise<Game | undefined> {
    const game = this.games.get(id);
    if (!game) return undefined;

    const completedGame: Game = {
      ...game,
      isCompleted: true,
    };
    this.games.set(id, completedGame);
    return completedGame;
  }

  async getRandomQuestions(limit: number): Promise<Question[]> {
    const allQuestions = Array.from(this.questions.values());
    const shuffled = allQuestions.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, limit);
  }

  async getAllQuestions(): Promise<Question[]> {
    return Array.from(this.questions.values());
  }
}

export const storage = new MemStorage();
