import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Game, Question } from "@shared/schema";
import TeamSetup from "@/components/team-setup";
import GameScreen from "@/components/game-screen";
import GameResults from "@/components/game-results";
import { Gamepad, Home } from "lucide-react";

type GamePhase = "setup" | "playing" | "results";

export default function GamePage() {
  const [gamePhase, setGamePhase] = useState<GamePhase>("setup");
  const [currentGame, setCurrentGame] = useState<Game | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const { toast } = useToast();

  // Fetch random questions for the game
  const { data: gameQuestions, isLoading: questionsLoading } = useQuery({
    queryKey: ["/api/questions/random/10"],
    enabled: false, // Only fetch when needed
  });

  // Create game mutation
  const createGameMutation = useMutation({
    mutationFn: async (gameData: { team1Name: string; team2Name: string }) => {
      const response = await apiRequest("POST", "/api/games", gameData);
      return response.json();
    },
    onSuccess: async (game: Game) => {
      setCurrentGame(game);
      // Fetch questions for the game
      const questionsResponse = await fetch("/api/questions/random/10");
      const questionsData = await questionsResponse.json();
      setQuestions(questionsData);
      setCurrentQuestionIndex(0);
      setGamePhase("playing");
      toast({
        title: "Game Started!",
        description: "Let the quiz battle begin!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start game. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update game mutation
  const updateGameMutation = useMutation({
    mutationFn: async (updateData: {
      gameId: number;
      team1Score: number;
      team2Score: number;
      currentQuestion: number;
      currentTeam: number;
    }) => {
      const { gameId, ...data } = updateData;
      const response = await apiRequest("PATCH", `/api/games/${gameId}`, data);
      return response.json();
    },
    onSuccess: (updatedGame: Game) => {
      setCurrentGame(updatedGame);
      queryClient.invalidateQueries({ queryKey: ["/api/games", updatedGame.id] });
    },
  });

  // Complete game mutation
  const completeGameMutation = useMutation({
    mutationFn: async (gameId: number) => {
      const response = await apiRequest("PATCH", `/api/games/${gameId}/complete`);
      return response.json();
    },
    onSuccess: (completedGame: Game) => {
      setCurrentGame(completedGame);
      setGamePhase("results");
      queryClient.invalidateQueries({ queryKey: ["/api/games", completedGame.id] });
    },
  });

  const handleStartGame = (team1Name: string, team2Name: string) => {
    createGameMutation.mutate({ team1Name, team2Name });
  };

  const handleAnswerSubmit = (selectedAnswer: string, isCorrect: boolean) => {
    if (!currentGame) return;

    let newTeam1Score = currentGame.team1Score;
    let newTeam2Score = currentGame.team2Score;

    // Award point to current team if correct
    if (isCorrect) {
      if (currentGame.currentTeam === 1) {
        newTeam1Score++;
      } else {
        newTeam2Score++;
      }
    }

    // Check if game is complete
    const isLastQuestion = currentGame.currentQuestion >= 10;
    
    if (isLastQuestion) {
      // Complete the game
      const finalUpdate = {
        gameId: currentGame.id,
        team1Score: newTeam1Score,
        team2Score: newTeam2Score,
        currentQuestion: currentGame.currentQuestion,
        currentTeam: currentGame.currentTeam,
      };
      
      updateGameMutation.mutate(finalUpdate, {
        onSuccess: () => {
          completeGameMutation.mutate(currentGame.id);
        },
      });
    } else {
      // Move to next question and switch teams
      const nextQuestion = currentGame.currentQuestion + 1;
      const nextTeam = currentGame.currentTeam === 1 ? 2 : 1;
      setCurrentQuestionIndex(currentQuestionIndex + 1);

      updateGameMutation.mutate({
        gameId: currentGame.id,
        team1Score: newTeam1Score,
        team2Score: newTeam2Score,
        currentQuestion: nextQuestion,
        currentTeam: nextTeam,
      });
    }
  };

  const handleResetGame = () => {
    setCurrentGame(null);
    setQuestions([]);
    setCurrentQuestionIndex(0);
    setGamePhase("setup");
  };

  const handlePlayAgain = () => {
    if (!currentGame) return;
    
    // Start new game with same teams
    createGameMutation.mutate({
      team1Name: currentGame.team1Name,
      team2Name: currentGame.team2Name,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600">
      {/* Header */}
      <header className="bg-white/10 backdrop-blur-sm border-b border-white/20 px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center">
              <Gamepad className="text-blue-600 w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold text-white">QuizBattle</h1>
          </div>
          <button 
            onClick={handleResetGame}
            className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg transition-all duration-200 font-medium"
          >
            <Home className="w-4 h-4 mr-2 inline" />
            Menu
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6">
        <div className="max-w-6xl mx-auto">
          {gamePhase === "setup" && (
            <TeamSetup 
              onStartGame={handleStartGame}
              isLoading={createGameMutation.isPending}
            />
          )}

          {gamePhase === "playing" && currentGame && questions.length > 0 && (
            <GameScreen
              game={currentGame}
              currentQuestion={questions[currentQuestionIndex]}
              onAnswerSubmit={handleAnswerSubmit}
              isLoading={updateGameMutation.isPending}
            />
          )}

          {gamePhase === "results" && currentGame && (
            <GameResults
              game={currentGame}
              onPlayAgain={handlePlayAgain}
              onNewTeams={handleResetGame}
              isLoading={createGameMutation.isPending}
            />
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white/5 backdrop-blur-sm border-t border-white/10 px-4 py-4">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-white/60 text-sm">QuizBattle - Educational Gaming Platform for Teens</p>
        </div>
      </footer>
    </div>
  );
}
