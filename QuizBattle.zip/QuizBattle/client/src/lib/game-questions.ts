import type { Question } from "@shared/schema";

export const gameQuestions: Omit<Question, "id">[] = [
  {
    category: "Science",
    question: "What is the chemical symbol for gold on the periodic table?",
    optionA: "Au",
    optionB: "Ag",
    optionC: "Go",
    optionD: "Gd",
    correctAnswer: "A"
  },
  {
    category: "History",
    question: "In which year did World War II end?",
    optionA: "1944",
    optionB: "1945",
    optionC: "1946",
    optionD: "1947",
    correctAnswer: "B"
  },
  {
    category: "Geography",
    question: "What is the capital city of Australia?",
    optionA: "Sydney",
    optionB: "Melbourne",
    optionC: "Canberra",
    optionD: "Perth",
    correctAnswer: "C"
  },
  {
    category: "Literature",
    question: "Who wrote the novel '1984'?",
    optionA: "Aldous Huxley",
    optionB: "George Orwell",
    optionC: "Ray Bradbury",
    optionD: "H.G. Wells",
    correctAnswer: "B"
  },
  {
    category: "Math",
    question: "What is the value of π (pi) to two decimal places?",
    optionA: "3.14",
    optionB: "3.16",
    optionC: "3.12",
    optionD: "3.18",
    correctAnswer: "A"
  },
  {
    category: "Science",
    question: "Which planet is known as the 'Red Planet'?",
    optionA: "Venus",
    optionB: "Jupiter",
    optionC: "Mars",
    optionD: "Saturn",
    correctAnswer: "C"
  },
  {
    category: "Sports",
    question: "How many players are on a basketball team on the court at one time?",
    optionA: "4",
    optionB: "5",
    optionC: "6",
    optionD: "7",
    correctAnswer: "B"
  },
  {
    category: "Technology",
    question: "What does 'HTTP' stand for?",
    optionA: "HyperText Transfer Protocol",
    optionB: "High Tech Transfer Protocol",
    optionC: "HyperText Transport Protocol",
    optionD: "High Transfer Text Protocol",
    correctAnswer: "A"
  },
  {
    category: "Art",
    question: "Who painted the famous artwork 'The Starry Night'?",
    optionA: "Pablo Picasso",
    optionB: "Leonardo da Vinci",
    optionC: "Vincent van Gogh",
    optionD: "Claude Monet",
    correctAnswer: "C"
  },
  {
    category: "Music",
    question: "How many strings does a standard guitar have?",
    optionA: "4",
    optionB: "5",
    optionC: "6",
    optionD: "7",
    correctAnswer: "C"
  }
];
