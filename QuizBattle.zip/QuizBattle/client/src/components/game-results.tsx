import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Trophy, Play, Users } from "lucide-react";
import type { Game } from "@shared/schema";

interface GameResultsProps {
  game: Game;
  onPlayAgain: () => void;
  onNewTeams: () => void;
  isLoading: boolean;
}

export default function GameResults({ game, onPlayAgain, onNewTeams, isLoading }: GameResultsProps) {
  const getWinner = () => {
    if (game.team1Score > game.team2Score) {
      return { name: game.team1Name, emoji: "🎉" };
    } else if (game.team2Score > game.team1Score) {
      return { name: game.team2Name, emoji: "🎉" };
    } else {
      return { name: "It's a Tie!", emoji: "🤝" };
    }
  };

  const winner = getWinner();

  return (
    <div className="text-center">
      <Card className="bg-white/10 backdrop-blur-sm border border-white/20">
        <CardContent className="p-12">
          <div className="mb-8">
            <Trophy className="text-yellow-400 w-16 h-16 mb-4 mx-auto animate-bounce" />
            <h2 className="text-4xl font-bold text-white mb-4">Game Complete!</h2>
            <p className="text-white/80 text-lg">Here are the final results</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-pink-500/20 rounded-2xl p-6 border border-pink-500/30">
              <h3 className="text-pink-500 font-bold text-xl mb-2">{game.team1Name}</h3>
              <div className="text-4xl font-bold text-white mb-2">{game.team1Score}</div>
              <div className="text-white/60 text-sm">points</div>
            </div>

            <div className="bg-emerald-500/20 rounded-2xl p-6 border border-emerald-500/30">
              <h3 className="text-emerald-500 font-bold text-xl mb-2">{game.team2Name}</h3>
              <div className="text-4xl font-bold text-white mb-2">{game.team2Score}</div>
              <div className="text-white/60 text-sm">points</div>
            </div>
          </div>

          <div className="mb-8">
            <div className="text-2xl font-bold text-white mb-2">
              {winner.emoji} {winner.name} {winner.name !== "It's a Tie!" ? "Wins!" : ""} {winner.emoji}
            </div>
            <p className="text-white/60">Congratulations on a great game!</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={onPlayAgain}
              disabled={isLoading}
              className="bg-white text-blue-600 font-bold hover:bg-white/90 disabled:opacity-50 transform hover:scale-105 transition-all duration-200"
            >
              {isLoading ? (
                "Starting..."
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Play Again
                </>
              )}
            </Button>
            <Button
              onClick={onNewTeams}
              variant="outline"
              className="bg-white/20 hover:bg-white/30 text-white border-white/30 hover:border-white/50 font-bold"
            >
              <Users className="w-4 h-4 mr-2" />
              New Teams
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
