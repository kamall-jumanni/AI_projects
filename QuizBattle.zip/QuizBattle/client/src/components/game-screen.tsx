import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Brain, Pause, RotateCcw, Check, X } from "lucide-react";
import type { Game, Question } from "@shared/schema";

interface GameScreenProps {
  game: Game;
  currentQuestion: Question;
  onAnswerSubmit: (selectedAnswer: string, isCorrect: boolean) => void;
  isLoading: boolean;
}

export default function GameScreen({ game, currentQuestion, onAnswerSubmit, isLoading }: GameScreenProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [lastAnswerCorrect, setLastAnswerCorrect] = useState(false);

  const progressPercentage = (game.currentQuestion / 10) * 100;
  const currentTeamName = game.currentTeam === 1 ? game.team1Name : game.team2Name;

  const answers = [
    { letter: "A", text: currentQuestion.optionA },
    { letter: "B", text: currentQuestion.optionB },
    { letter: "C", text: currentQuestion.optionC },
    { letter: "D", text: currentQuestion.optionD },
  ];

  const handleAnswerClick = (answerLetter: string) => {
    if (selectedAnswer || isLoading) return;

    setSelectedAnswer(answerLetter);
    const isCorrect = answerLetter === currentQuestion.correctAnswer;
    setLastAnswerCorrect(isCorrect);
    setShowFeedback(true);
  };

  const handleContinue = () => {
    if (!selectedAnswer) return;

    setShowFeedback(false);
    onAnswerSubmit(selectedAnswer, lastAnswerCorrect);
    setSelectedAnswer(null);
  };

  return (
    <div>
      {/* Score Header */}
      <Card className="bg-white/10 backdrop-blur-sm border border-white/20 mb-6">
        <CardContent className="p-6">
          <div className="grid grid-cols-3 items-center">
            <div className="text-center">
              <div className="bg-pink-500/20 rounded-xl p-4">
                <h3 className="text-pink-500 font-bold text-lg mb-2">{game.team1Name}</h3>
                <div className="text-3xl font-bold text-white">{game.team1Score}</div>
              </div>
            </div>

            <div className="text-center">
              <div className="text-white/60 text-sm font-medium mb-1">Question</div>
              <div className="text-2xl font-bold text-white">{game.currentQuestion} / 10</div>
              <div className="w-full bg-white/20 rounded-full h-2 mt-2">
                <div 
                  className="bg-white h-2 rounded-full transition-all duration-500" 
                  style={{ width: `${progressPercentage}%` }}
                />
              </div>
            </div>

            <div className="text-center">
              <div className="bg-emerald-500/20 rounded-xl p-4">
                <h3 className="text-emerald-500 font-bold text-lg mb-2">{game.team2Name}</h3>
                <div className="text-3xl font-bold text-white">{game.team2Score}</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Current Turn Indicator */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center bg-white/10 backdrop-blur-sm rounded-full px-6 py-3 border border-white/20">
          <div className={`w-4 h-4 rounded-full mr-3 animate-pulse ${
            game.currentTeam === 1 ? 'bg-pink-500' : 'bg-emerald-500'
          }`} />
          <span className="text-white font-medium">{currentTeamName}'s Turn</span>
        </div>
      </div>

      {/* Question Card */}
      <Card className="bg-white rounded-3xl shadow-2xl mb-6">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center bg-blue-600/10 text-blue-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Brain className="w-4 h-4 mr-2" />
              {currentQuestion.category}
            </div>
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800 leading-relaxed">
              {currentQuestion.question}
            </h2>
          </div>

          {/* Answer Options */}
          <div className="grid md:grid-cols-2 gap-4">
            {answers.map((answer) => (
              <button
                key={answer.letter}
                onClick={() => handleAnswerClick(answer.letter)}
                disabled={selectedAnswer !== null || isLoading}
                className={`bg-gray-50 hover:bg-blue-600 hover:text-white border-2 border-gray-200 hover:border-blue-600 rounded-2xl p-6 text-left transition-all duration-200 transform hover:scale-105 group disabled:opacity-50 disabled:cursor-not-allowed ${
                  selectedAnswer === answer.letter ? 'bg-blue-600 text-white border-blue-600' : ''
                }`}
              >
                <div className="flex items-center">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mr-4 font-bold transition-colors ${
                    selectedAnswer === answer.letter 
                      ? 'bg-white/20 text-white' 
                      : 'bg-gray-200 text-gray-600 group-hover:bg-white/20 group-hover:text-white'
                  }`}>
                    {answer.letter}
                  </div>
                  <span className={`font-medium text-lg transition-colors ${
                    selectedAnswer === answer.letter 
                      ? 'text-white' 
                      : 'text-gray-800 group-hover:text-white'
                  }`}>
                    {answer.text}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Game Controls */}
      <div className="flex justify-center space-x-4">
        <Button 
          variant="outline"
          className="bg-white/20 hover:bg-white/30 text-white border-white/30 hover:border-white/50"
        >
          <Pause className="w-4 h-4 mr-2" />
          Pause Game
        </Button>
        <Button 
          variant="outline"
          className="bg-white/20 hover:bg-white/30 text-white border-white/30 hover:border-white/50"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset Game
        </Button>
      </div>

      {/* Feedback Modal */}
      <Dialog open={showFeedback} onOpenChange={setShowFeedback}>
        <DialogContent className="bg-white rounded-3xl max-w-md mx-4 text-center">
          {lastAnswerCorrect ? (
            <div>
              <div className="w-20 h-20 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Check className="text-green-500 w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">Correct!</h3>
              <p className="text-gray-600 mb-4">Great job! Your team earned 1 point.</p>
              <Button 
                onClick={handleContinue}
                className="bg-green-500 text-white hover:bg-green-600"
                disabled={isLoading}
              >
                {isLoading ? "Loading..." : "Continue"}
              </Button>
            </div>
          ) : (
            <div>
              <div className="w-20 h-20 bg-red-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <X className="text-red-500 w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">Incorrect</h3>
              <p className="text-gray-600 mb-2">The correct answer was:</p>
              <p className="text-blue-600 font-bold mb-4">
                {currentQuestion.correctAnswer}) {
                  answers.find(a => a.letter === currentQuestion.correctAnswer)?.text
                }
              </p>
              <Button 
                onClick={handleContinue}
                className="bg-red-500 text-white hover:bg-red-600"
                disabled={isLoading}
              >
                {isLoading ? "Loading..." : "Continue"}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
