import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Users, Play } from "lucide-react";

interface TeamSetupProps {
  onStartGame: (team1Name: string, team2Name: string) => void;
  isLoading: boolean;
}

export default function TeamSetup({ onStartGame, isLoading }: TeamSetupProps) {
  const [team1Name, setTeam1Name] = useState("");
  const [team2Name, setTeam2Name] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!team1Name.trim() || !team2Name.trim()) {
      return;
    }

    onStartGame(team1Name.trim(), team2Name.trim());
  };

  const isValid = team1Name.trim().length > 0 && team2Name.trim().length > 0;

  return (
    <div>
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold text-white mb-4">Setup Your Teams</h2>
        <p className="text-white/80 text-lg">Enter team names and get ready to battle!</p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <Card className="bg-white/10 backdrop-blur-sm border border-white/20">
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-pink-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Users className="text-white w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-pink-500 mb-2">Team 1</h3>
              </div>
              <Input
                type="text"
                placeholder="Enter team name..."
                value={team1Name}
                onChange={(e) => setTeam1Name(e.target.value)}
                className="w-full bg-white/20 border border-white/30 text-white placeholder-white/60 focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                disabled={isLoading}
              />
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border border-white/20">
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-emerald-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Users className="text-white w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-emerald-500 mb-2">Team 2</h3>
              </div>
              <Input
                type="text"
                placeholder="Enter team name..."
                value={team2Name}
                onChange={(e) => setTeam2Name(e.target.value)}
                className="w-full bg-white/20 border border-white/30 text-white placeholder-white/60 focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                disabled={isLoading}
              />
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <Button
            type="submit"
            disabled={!isValid || isLoading}
            className="bg-white text-blue-600 px-8 py-4 text-lg font-bold hover:bg-white/90 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 transition-all duration-200 shadow-lg"
          >
            {isLoading ? (
              "Starting..."
            ) : (
              <>
                <Play className="w-5 h-5 mr-2" />
                Start Game
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}
